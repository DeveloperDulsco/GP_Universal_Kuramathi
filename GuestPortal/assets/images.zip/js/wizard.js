﻿
function moveToNextTab(currentTab) {


    var currentTabIndex = $('.tab-pane').index($(currentTab).parents('div.tab-pane'));

    var nextTab = $(currentTab).parents('div.tab-pane').next();

    if (currentTabIndex == 0) {
        if (upselAvailable == "False") {
            $(nextTab).find('.btn_next').click();
        }
    }

    

    if (nextTab.length > 0) {
        $(currentTab).parents('div.tab-pane').removeClass('active');
        $(currentTab).parents('div.tab-pane').next().addClass('active');
        $("html, body").animate({ scrollTop: 0 }, "slow");
        setActiveTabs(currentTabIndex);
        if (+currentTabIndex == 1) {
            initCanvas();
        }
    }

    if (currentTabIndex == 2) {
        //if (IsDepositAvailable == "True") {
        //    $(nextTab).find('.btn_next').click();
        //}
    }
}

$(document).ready(function () {
    $('.tabs').on('click', function () {

        return;

        if ($(this).hasClass('paymentdone')) {
            return;
        }

        var target = $(this).attr('href');
        var tabIndex = $('.tabs').index($(this));
        if (+tabIndex == 2) {
            initCanvas();
        }

        if (+tabIndex == 3) {

            if (!validateTermsAndConditions()) {
                $('#messageContent').html("Please accept terms and conditions.");
                $('#exampleModal2').modal('show');
                return;
            }
            else {
                if (signaturePad.isEmpty()) {
                    $('#messageContent').html("Please Sign the registration card.");
                    $('#exampleModal2').modal('show');
                    return;
                }
            }
        }

        if ($("form[name='frm_guestdetails']").valid()) {

            $('.tabs').each(function (e) {

                var hTarget = $(this).attr('href');

                $(hTarget).removeClass('active');

            });

            $(target).addClass('active');

            $("html, body").animate({ scrollTop: 0 }, "slow");
        }

    });

    $('.moveNext').on('click', function (e) {
        e.preventDefault();

        var currentTabIndex = $('.tab-pane').index($(this).parents('div.tab-pane'));

        if ($("form[name='frm_guestdetails']").valid()) {
            moveToNextTab(this);
        }
        else {
            $('#messageContent').html("Please fill the missing details.");
            $('#exampleModal2').modal('show');
        }
    });

    $('.btn_cancel').on('click', function (e) {
        e.preventDefault();
        var prevTab = $(this).parents('div.tab-pane').prev();
        var currentTabIndex = $('.tab-pane').index($(this).parents('div.tab-pane'));
        if (prevTab.length > 0) {
            $(this).parents('div.tab-pane').removeClass('active');
            $(this).parents('div.tab-pane').prev().addClass('active');
            setActiveTabs(currentTabIndex - 2);
            $("html, body").animate({ scrollTop: 0 }, "slow");
        }
    });
});


function validateTermsAndConditions() {
    return $('#acceptTermsAndCondition').is(':checked');
}


var initCanvas = function () {
    var wrapper = document.getElementById("signature-pad");
    var clearButton = wrapper.querySelector("[data-action=clear]");
    var changeColorButton = wrapper.querySelector("[data-action=change-color]");
    var canvas = wrapper.querySelector("canvas");

    signaturePad = new SignaturePad(canvas, {
        backgroundColor: 'rgb(255, 255, 255)'
    });

    clearButton.addEventListener("click", function (event) {
        signaturePad.clear();
    });
}

var setActiveTabs = function (currentTabIndex) {
    //loop and make tab title active till current tab
    $('.tabs').each(function (i, e) {
        $(this).removeClass('active');
        if (i <= +currentTabIndex + 1) {
            $(this).addClass('active');
        }
    });
}

function getCookie(name) {
    // Split cookie string and get all individual name=value pairs in an array
    var cookieArr = document.cookie.split(";");

    // Loop through the array elements
    for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");

        /* Removing whitespace at the beginning of the cookie name
        and compare it with the given string */
        if (name == cookiePair[0].trim()) {
            // Decode the cookie value and return
            return decodeURIComponent(cookiePair[1]);
        }
    }

    // Return null if not found
    return null;
}


// Wait for the DOM to be ready
$(function () {

    //var language = getCookie("culture");
   //alert(language);

    $.validator.addMethod("time", function (value, element) {
        if (value) {
            return this.optional(element) || /^(([0-1]?[0-9])|([2][0-3])):([0-5]?[0-9])(:([0-5]?[0-9]))?$/i.test(value);
        }
        return false;
    }, "Please enter a valid time.");

    $.validator.addMethod(
        "regex",
        function (value, element, regexp) {
            var re = new RegExp(regexp);
            return this.optional(element) || re.test(value);

            //var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

            //return re.test(nationality);
        },
        "Please check your input."
    );

    $.validator.addMethod("ValidateExpiryDate", function (value, element) {
        //var today = new Date();
        //console.log(today);
        //console.log(value);


        //var dd = today.getDate();
        //var mm = today.getMonth() + 1;

        //var yyyy = today.getFullYear();
        //if (dd < 10) {
        //    dd = '0' + dd;
        //}
        //if (mm < 10) {
        //    mm = '0' + mm;
        //}
        //var today = dd + '/' + mm + '/' + yyyy;
        ////var today = mm + '/' + dd + '/' + yyyy;
        //console.log(today);
        //console.log(today < value)

        //return this.optional(element) || today <= value;

        var today = new Date(); // current date as Date object
        console.log(today);     // logs current date object
        console.log(value);     // logs input date string (expected in "dd/mm/yyyy")

        // Convert 'value' (the input date string) into a Date object
        var parts = value.split('/');
        var inputDate = new Date(parts[2], parts[1] - 1, parts[0]); // year, month (0-indexed), day
        console.log(inputDate);  // logs parsed Date object

        // Perform the comparison using Date objects
        console.log(today < inputDate); // should compare correctly now

        return this.optional(element) || today <= inputDate;
    });

    $.validator.addMethod("ValidateBirthDate", function (value, element) {
        var today = new Date();
        console.log(today);
        console.log(value);


        var dd = today.getDate();
        var mm = today.getMonth() + 1;

        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        var today = dd + '/' + mm + '/' + yyyy;
        //var today = mm + '/' + dd + '/' + yyyy;
        console.log(today);
        console.log(today < value)

        return this.optional(element) || today > value;
    });

    // Initialize form validation on the registration form.
    // It has the name attribute "registration"
    $("form[name='frm_guestdetails']").validate({
        // Specify validation rules
        rules: {
            // The key name on the left side is the name attribute
            // of an input field. Validation rules are defined
            // on the right side
            'Profiles[0].Phone':
            {
                required: true,
               // number: true
                regex: /^[\+]?[0-9 ]{4,15}$/im
            },
            'Profiles[0].AddressLine1': "required",
            'Profiles[0].City': "required",
            'Profiles[0].PostalCode': "required",
            'Profiles[0].StateID': {
                required: false,
            },
            'Profiles[0].NationnalityID':"required",
            'Profiles[0].Email': {
                required: true,
                email: true
            },
            'Profiles[0].CountryID': {
                required: true,
            },
            'ExpectedTimeofArrival': {
                time : true
            },
            'Profiles[0].DocumentNumber': {
                required: function (element) {

                    //Do the condition check
                    var nationality = $('#Profiles_0__NationnalityID').val();

                    if (nationality != '' ) {
                        if (nationality == "89") {
                            return false;
                        }
                        else {
                            return true;
                        }
                    }
                    else {
                        return false;
                    }


                }
            },
            'Profiles[0].ExpiryDate': {
                required: function (element) {

                    //Do the condition check
                    var nationality = $('#Profiles_0__NationnalityID').val();

                    if (nationality != '') {
                        if (nationality == "89") {
                            return false;
                        }
                        else {
                            return true;
                        }
                    }
                    else {
                        return false;
                    }


                },
                ValidateExpiryDate: {
                    ValidateExpiryDate : true
                }
            },
            'Profiles[0].PlaceOfBirth': {
                required: function (element) {

                    //Do the condition check
                    return nationalityValidation()


                }
            },
            'Profiles[0].DateOfBirth': {
                required: function (element) {

                    //Do the condition check
                    return nationalityValidation()


                },
                ValidateBirthDate: {
                    ValidateBirthDate: true
                }
            },
            'Profiles[0].placeofissue': {
                required: function (element) {

                    //Do the condition check
                    return nationalityValidation()


                }
            },
            'nextdestination': {
                required: function (element) {
                    return nationalityValidation()
                }
            }
           
        },
        // Specify validation error messages
        messages: {
            'Profiles[0].Phone': {
                "required": language != null && language == "fr" ? "Veuillez entrer votre numéro de téléphone" : "Please enter your phone number",
                'regex': language != null && language == "fr" ? 'Numéro de téléphone invalide' : 'Invalid phone number'
            },
            'Profiles[0].AddressLine1': language != null && language == "fr" ? "Veuillez saisir l'adresse" : "Please enter the address",
            'Profiles[0].City': language != null && language == "fr" ? "Veuillez entrer la ville" : "Please enter the city",
            'Profiles[0].PostalCode': language == "fr" ? "Veuillez saisir le code postal" : "Please enter the Postal Code",
            'Profiles[0].StateID': language == "fr" ? "Veuillez saisir l'état" : "Please enter the state",
            'Profiles[0].Email': language == "fr" ? "S'il vous plaît, mettez une adresse email valide" : "Please enter a valid email address",
            'Profiles[0].CountryID': language == "fr" ? "Veuillez sélectionner le pays" : "Please select the country",
            'ExpectedTimeofArrival': language == "fr" ? "Veuillez entrer l'heure d'arrivée prévue" : "Please enter the expected time of arrival",
            'Profiles[0].NationnalityID': language == "fr" ? "Veuillez sélectionner la nationalité" : "Please select the nationality",
            'Profiles[0].DocumentNumber': language == "fr" ? 'Veuillez saisir le numéro de passeport' : 'Please enter the passport number',
            /*'Profiles[0].ExpiryDate': language == "fr" ? "Veuillez saisir la date d'expiration" : "Please enter the expiry date",*/
            'Profiles[0].ExpiryDate': {
                "required": language == "fr" ? "Veuillez saisir la date d'expiration" : "Please enter the expiry date",
                "ValidateExpiryDate": language == "fr" ? "Document déjà expiré" : "Document already expired",
            },
            'Profiles[0].placeofissue': language == "fr" ? "Veuillez saisir le lieu d'émission" : "Please enter the place of issue",
            'Profiles[0].DateOfBirth':
                {
                    "required":  language == "fr" ? "Veuillez entrer la date de naissance valide" : "Please enter the valid date of birth",
                    "ValidateBirthDate": language == "fr" ? "Veuillez entrer la date de naissance valide" : "Please enter the valid date of birth"
                },
            'Profiles[0].PlaceOfBirth': language == "fr" ? "Veuillez saisir le lieu de naissance" : "Please enter the place of birth",
            'nextdestination': language == "fr" ? "Veuillez entrer la prochaine destination" : "Please enter the next destination"
            
        },
        errorPlacement: function (error, element, label) {
            if (element.hasClass('selectpicker') && element.next('button').next('.dropdown-menu').length) {
                error.insertAfter(element.next('button').next('.dropdown-menu'));
            }
            else {
                error.insertAfter(element);

            }
        },
        // Make sure the form is submitted to the destination defined
        // in the "action" attribute of the form when valid
        submitHandler: function (form) {

            //form.submit();
        },
        invalidHandler: function (form, validator) {
            var errors = validator.numberOfInvalids();
            if (errors) {
                var el = validator.errorList[0].element;
                $('html, body').animate({ scrollTop: $(el).offset().top - 250 }, 'slow', function () {
                    validator.errorList[0].element.focus();
                });
                
            }
        }
    });

    function validatePhoneNumber() {
        var nationality = $('#phone').val();

        var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

        return re.test(nationality);
    }

    function nationalityValidation() {
        var nationality = $('#Profiles_0__NationnalityID').val();

        if (nationality != '') {
            if (nationality == "89") {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    function documentExpiryValidation() {
        //var expiry = $('#ExpiryDate').val();
        //var today = new Date();
        //if (expiry < today)
        //{
        //    return false;
        //}
        ////console.log(expiry);
        return true;
    }


    $("form[name='frmDeclaration']").validate({
        errorPlacement: function (error, element, label) {
            if (element.hasClass('declarationRadio')) {

                if (element.parents('div.ans').length > 0) {
                    element.parents('div.ans').append(error);
                }
                else {
                    error.insertAfter(element);
                }
            }
            else {
                error.insertAfter(element);

            }
        },
        // Make sure the form is submitted to the destination defined
        // in the "action" attribute of the form when valid
        submitHandler: function (form) {

            //form.submit();
        },
        invalidHandler: function (form, validator) {
            var errors = validator.numberOfInvalids();
            if (errors) {
                var el = validator.errorList[0].element;
                $('html, body').animate({ scrollTop: $(el).offset().top - 250 }, 'slow', function () {
                    validator.errorList[0].element.focus();
                });

            }
        }
    });



});

function validateSetp() {





}