﻿using CheckinPortal.BusinessLayer;
using CheckinPortal.DataAccess;
using CheckinPortal.Helpers;
using CheckinPortal.Models;
using CheckinPortal.Models.AdaptorAPIModels;
using CheckinPortal.Models.OWS;
using CheckinPortal.Models.PaymentDetails;
using Newtonsoft.Json;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Mapping;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Windows;
using static QRCoder.PayloadGenerator;

namespace CheckinPortal.Controllers
{
    public class HomeController : Controller
    {
        ReservationLogics reservationLogics = new ReservationLogics();

        public async Task<ActionResult> Index(string id)
        {
            Session.Clear();
            Session.Abandon();
            ViewBag.id = id;

            string ActionName = "Index";
            string ActionGroup = "Pre-Checkin";
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            var languageSession = "en";

            if (Request.Cookies.AllKeys.Contains("culture"))
            {
                languageSession = Request.Cookies["culture"].Value.ToString();
            }


            //if (Session["SelectedLanguage"] == null)
            {
                Session["SelectedLanguage"] = languageSession;
            }



            var test = Url.Encode(Helpers.EncryptionHelper.EncryptString("375414"));
            if (string.IsNullOrEmpty(id))
            {
                return View("ReservationNotFound");
            }

            string confirmationNo = Helpers.EncryptionHelper.DecryptString(id.ToString());

            if (string.IsNullOrEmpty(confirmationNo))
            {
                Helpers.LogHelper.Instance.Warn($"Unable to decrypt the confirmation no {id.ToString()}", "0", ActionName, ActionGroup);
                return View("ReservationNotFound");
            }

            ViewBag.ReservationFound = false;
            ViewBag.PaymentProcessed = false;

            Models.ReservationModel reservationModel = new Models.ReservationModel();
            reservationModel.IsDepositAvailable = false;

            MastersLogics mastersLogics = new MastersLogics();

            var CountryList = await new CloudHelper().fetchcountryMaster(ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString(), ActionGroup);

            var reservationsDt = await new CloudHelper().FetchReservationDetailsByReferenceNumber(confirmationNo, new APIRequestModel { RequestObject = confirmationNo }, "", ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString());
            var reservations = new CloudReservationModel();
            if (reservationsDt?.responseData != null)
            {
                reservations = JsonConvert.DeserializeObject<List<CloudReservationModel>>(reservationsDt.responseData.ToString()).FirstOrDefault();

            }


            if (reservations != null)
            {
                var reservationfromopera = await new CloudHelper().fetchReservationFromPMS(new Models.OWS.OwsRequestModel()
                {
                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                    LegNumber = "1",
                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                    FetchBookingRequest = new Models.OWS.FetchBookingRequestModel()
                    {
                        ReservationNumber = confirmationNo

                    }
                }, ConfigurationManager.AppSettings["APIBaseUrl"].ToString(), "precheckin", ActionGroup);

                if (reservationfromopera != null && reservationfromopera.Count > 0)
                {

                    if (reservationfromopera.First().Adults != null && reservationfromopera.First().Adults.Value > 0)
                        SessionData.OperaReservation = reservationfromopera.First();

                    bool isredirectfromPaymentPage = false;
                    bool IsPaymentSuccess = false;
                    string PaymentFailureMessage = "";

                    if (TempData["IsredirectedfromPaymentPage"] != null)
                    {
                        isredirectfromPaymentPage = Convert.ToBoolean(TempData["IsredirectedfromPaymentPage"].ToString());
                        IsPaymentSuccess = Convert.ToBoolean(TempData["IsPaymentSuccess"].ToString());
                        PaymentFailureMessage = TempData["PaymentFailureMessage"].ToString();
                    }

                    ViewBag.IsredirectedfromPaymentPage = isredirectfromPaymentPage;
                    ViewBag.IsPaymentSuccess = IsPaymentSuccess;
                    ViewBag.PaymentFailureMessage = PaymentFailureMessage;

                    ViewBag.uploadcomplete = false;


                    if (reservations.IsPreCheckedInPMS.HasValue && !reservations.IsPreCheckedInPMS.Value || isredirectfromPaymentPage)
                    {
                        ViewBag.ReservationFound = true;

                        #region Get the existing selected package and Upsells

                        var ReservationPackagesList = reservationLogics.GetReservationPackages(reservations.ReservationDetailID);

                        if (ReservationPackagesList != null && ReservationPackagesList.Count > 0)
                        {
                            Helpers.LogHelper.Instance.Log($"Existing reservation packages found.", $"{confirmationNo}", ActionName, ActionGroup);

                            var RoomUpsellPackages = ReservationPackagesList.Where(x => x.IsRoomUpsell).Select(x => x.PackageID).ToArray();
                            var SpecialsPackages = ReservationPackagesList.Where(x => !x.IsRoomUpsell).Select(x => x.PackageID).ToArray();

                            ViewBag.RoomUpsellPackages = string.Join(",", RoomUpsellPackages);
                            ViewBag.SpecialPackages = string.Join(",", SpecialsPackages);
                            ViewBag.ReservationPackagesList = ReservationPackagesList;
                        }
                        else
                        {
                            Helpers.LogHelper.Instance.Log($"Existing reservation packages not found.", $"{confirmationNo}", ActionName, ActionGroup);
                            ViewBag.RoomUpsellPackages = string.Empty;
                            ViewBag.SpecialPackages = string.Empty;
                            ViewBag.ReservationPackagesList = new List<ReservationPackageModel>();
                        }
                        #endregion
                        #region VerifyVIPReservationOrNot
                        new LogHelper().Log("Verifying reservation VIP status in UDF field", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        if (SessionData.OperaReservation.userDefinedFields != null && SessionData.OperaReservation.userDefinedFields.Count > 0)
                        {
                            if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthUDF"].ToString())) != null &&
                                SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthUDF"].ToString())).FieldValue.Equals("NO"))
                            {
                                new LogHelper().Log("Reservation is flagged not to take payment", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                {
                    new Models.OWS.DepositDetail()
                    {
                        Amount = 0,
                        CardExpiryDate = null,
                        CreditCardNumber = null,
                        IsCreditCardDeposit = false,
                        PaymentType = null
                    }
                };
                                SessionData.OperaReservation.IsDepositAvailable = true;
                            }
                            else if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthAmntUDF"])) != null &&
                                SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthAmntUDF"])).FieldValue.Equals("NO"))
                            {

                                new LogHelper().Log("Reservation is flagged not to take payment", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                        {
                            new Models.OWS.DepositDetail()
                            {
                                Amount = 0,
                                CardExpiryDate = null,
                                CreditCardNumber = null,
                                IsCreditCardDeposit = false,
                                PaymentType = null
                            }
                        };

                                SessionData.OperaReservation.IsDepositAvailable = true;
                            }
                        }
                        new LogHelper().Log("Verifying reservation VIP status in UDF field completed", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        #endregion

                        #region PaymentDesabling
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings
                    ["IsPaymentDisabled"]))
                        {
                            new LogHelper().Log("Disabling the payment as per the config", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                {
                    new Models.OWS.DepositDetail()
                    {
                        Amount = 0,
                        CardExpiryDate = null,
                        CreditCardNumber = null,
                        IsCreditCardDeposit = false,
                        PaymentType = null
                    }
                };
                            SessionData.OperaReservation.IsDepositAvailable = true;
                        }
                        #endregion

                        #region Update ETA
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsETADefault"]))
                        {
                            new LogHelper().Log("Assigning NULL value to ETA as per the config", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            SessionData.OperaReservation.ExpectedArrivalTime = null;
                        }
                        #endregion

                        #region Processing RoomRate
                        new LogHelper().Log("Updating rate details", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        if (SessionData.OperaReservation.RateDetails != null && SessionData.OperaReservation.RateDetails.DailyRates != null && SessionData.OperaReservation.RateDetails.DailyRates.Count > 0)
                        {
                            decimal total_roomrate = SessionData.OperaReservation.RateDetails.DailyRates.Sum(x => x.Amount);
                            if (SessionData.OperaReservation.PrintRate != null && SessionData.OperaReservation.PrintRate.Value)
                                SessionData.OperaReservation.RateDetails.RateAmount = total_roomrate;
                            else
                                SessionData.OperaReservation.TotalAmount = 0;
                            new LogHelper().Log("Updating rate details completed", SessionData.OperaReservation.ReservationNameID, "Index", "Pre-Checkin");
                        }
                        else
                            new LogHelper().Log("Updating rate details failed because Rate details are blank in the reservation", SessionData.OperaReservation.ReservationNameID, "Index", "Pre-Checkin");
                        #endregion


                        #region Processing MealPlan
                        if (ConfigurationManager.AppSettings["IsBreakFastValidationWithUDF"] != null && Convert.ToBoolean(ConfigurationManager.AppSettings["IsBreakFastValidationWithUDF"]))
                        {
                            new LogHelper().Debug("Processing meal plan from UDF fields", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            if (SessionData.OperaReservation.userDefinedFields != null && SessionData.OperaReservation.userDefinedFields.Count > 0)
                            {
                                if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])) != null)
                                {

                                    if (!SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])).FieldValue.Equals("NP"))
                                    {
                                        string tempUDFValue = SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])).FieldValue;
                                        if (!string.IsNullOrEmpty(tempUDFValue))
                                        {
                                            bool isPackageFound = false;
                                            if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(tempUDFValue))
                                                isPackageFound = true;
                                            if (isPackageFound)
                                            {
                                                SessionData.OperaReservation.IsBreakFastAvailable = true;
                                                new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                            }
                                        }
                                    }
                                    else
                                        new LogHelper().Log("Processing meal plan not updated (NP not present in UDF)", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup); ;
                                }
                            }
                            else
                                new LogHelper().Log("No UDF fields for meal plan not found", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        }
                        if (ConfigurationManager.AppSettings["IsBreakFastValidationWithPackage"] != null && Convert.ToBoolean(ConfigurationManager.AppSettings["IsBreakFastValidationWithPackage"]))
                        {
                            new LogHelper().Debug("Processing package list in the reservation for meal plan", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            if (((SessionData.OperaReservation.PackageDetails != null && SessionData.OperaReservation.PackageDetails.Count > 0) || (SessionData.OperaReservation.PreferanceDetails != null && SessionData.OperaReservation.PreferanceDetails.Count > 0)) && (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["PackageCodes"]) && ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList() != null))
                            {
                                if (SessionData.OperaReservation.PackageDetails != null && SessionData.OperaReservation.PackageDetails.Count > 0)
                                {
                                    bool isPackageFound = false;
                                    foreach (Models.OWS.PackageDetails package in SessionData.OperaReservation.PackageDetails)
                                    {
                                        if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(package.PackageCode))
                                        {
                                            isPackageFound = true;
                                            break;
                                        }
                                    }
                                    if (isPackageFound)
                                    {
                                        SessionData.OperaReservation.IsBreakFastAvailable = true;
                                        new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                    }
                                }
                                if (SessionData.OperaReservation.PreferanceDetails != null && SessionData.OperaReservation.PreferanceDetails.Count > 0)
                                {
                                    if (SessionData.OperaReservation.IsBreakFastAvailable == null || !SessionData.OperaReservation.IsBreakFastAvailable.Value)
                                    {
                                        bool isPrefernceFound = false;
                                        foreach (Models.OWS.PreferanceDetails prefernce in SessionData.OperaReservation.PreferanceDetails)
                                        {
                                            if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(prefernce.PreferanceCode))
                                            {
                                                isPrefernceFound = true;
                                                break;
                                            }
                                        }
                                        if (isPrefernceFound)
                                        {
                                            SessionData.OperaReservation.IsBreakFastAvailable = true;
                                            new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                        }
                                    }
                                }
                            }
                            else
                                new LogHelper().Log("No package or prefernce list in the reservation for meal plan not found", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        }
                        #endregion
                        if ((reservations.IsEcomchekinPaymentStaus != null && reservations.IsEcomchekinPaymentStaus.Value) || isredirectfromPaymentPage)
                        {
                            Helpers.LogHelper.Instance.Log($"Reservation #{confirmationNo} payment already done.", $"{confirmationNo}", ActionName, ActionGroup);
                            ViewBag.PaymentProcessed = true;
                            ViewBag.IsPaymentSuccess = true;
                        }
                       
                        // var Questions = reservationLogics.GetQuestions();
                        var PackageLists = reservationLogics.GetPackages(SessionData.OperaReservation.RoomDetails.RoomType);
                        ViewBag.PackageList = PackageLists;
                        // ViewBag.Questions = Questions;

                        //push events to DB
                        reservationLogics.InsertEvent(reservations.ReservationDetailID, "Email Link Click");

                        Helpers.LogHelper.Instance.Log($"Getting prfile details", $"{confirmationNo}", ActionName, ActionGroup);
                        var ProfileList = await reservationLogics.GetReservationProfileList(reservations.ReservationDetailID);

                        ViewBag.Profiles = ProfileList;
                        ViewBag.CountryList = new SelectList(CountryList, "CountryMasterID", "Country_Full_name", ProfileList[0].CountryMasterID);

                        if (ProfileList[0].CountryMasterID != null)
                        {
                            var StateList = mastersLogics.GetStateListByCountryID(ProfileList[0].CountryMasterID.Value);
                            ViewBag.StateList = new SelectList(StateList, "StateMasterID", "Statename", ProfileList[0].StateMasterID);
                        }
                        else
                        {
                            List<Models.StateMaster> tbstateMasters = new List<Models.StateMaster>();
                            tbstateMasters.Add(new Models.StateMaster()
                            {
                                Statename = "Please select country",
                                StateMasterID = -1

                            });
                            ViewBag.StateList = new SelectList(tbstateMasters, "StateMasterID", "Statename", "Select State");

                        }
                        CountryList.Add(new tbCountryMaster()
                        {
                            CountryMasterID = -1,
                            Country_Full_name = "Please select nationality"
                        });
                        ViewBag.NationalityList = new SelectList(CountryList, "CountryMasterID", "Country_Full_name", "Please select nationality");




                        List<Models.Profile> profiles = new List<Models.Profile>();
                        int i = 0;
                        foreach (var profile in ProfileList)
                        {
                            if (profile.DocumentImage1 != null)
                            {
                                if (profile.DocumentImage1.Length > 0)
                                {
                                    i++;
                                }
                                else if (!string.IsNullOrEmpty(profile.DocumentNumber) && profile.DocumentNumber.Length > 0)
                                {
                                    i++;
                                }
                            }
                            else if (!string.IsNullOrEmpty(profile.DocumentNumber) && profile.DocumentNumber.Length > 0)
                            {
                                i++;
                            }
                            profiles.Add(new Models.Profile()
                            {
                                AddressLine1 = profile.AddressLine1,
                                AddressLine2 = profile.AddressLine2,
                                City = profile.City,
                                CountryID = profile.CountryMasterID,
                                Email = profile.Email,
                                FirstName = profile.FirstName,
                                LastName = profile.LastName,
                                Phone = profile.Phone,
                                PostalCode = profile.PostalCode != null ? profile.PostalCode : "",
                                StateID = profile.StateMasterID,
                                ProfileDetailID = profile.ProfileDetailID,
                                ProfileID = Convert.ToInt32(profile.ProfileID ?? "0"),
                                MiddleName = profile.MiddleName,
                                DocumentImage1 = profile.DocumentImage1 != null ? "0" : "1"
                            });
                        }
                        if (profiles != null)
                        {
                            if (profiles.Count() > 0 && profiles.Count() == i)
                            {
                                reservationLogics.UpdateReservationByStage("Upload Completes", new UpdateReservationModel()
                                {
                                    ReservationID = reservations.ReservationDetailID
                                });
                                ViewBag.uploadcomplete = true;
                                reservations.IsUploadComplete = true;
                            }
                        }

                        decimal TotalRoomRate = 0;
                        TotalRoomRate = SessionData.OperaReservation.TotalAmount.HasValue ? SessionData.OperaReservation.TotalAmount.Value : 0;


                        string ExpectedTimeofArrival = "";

                        if (reservations.ETA.HasValue && !(reservations.ETA.Value.ToString("HH:mm") == "00:00"))
                        {
                            Helpers.LogHelper.Instance.Log($"Estimate time of arrival already exist {reservations.ETA.Value.ToString("HH:mm")} ", $"{confirmationNo}", ActionName, ActionGroup);
                            DateTime timeUtc = reservations.ETA.Value;
                            ExpectedTimeofArrival = Helpers.DateTimeHelper.ConvertFromUTC(timeUtc);
                        }

                        //Added For breakfast included
                        bool IsBreakFastAvailable;
                        if (SessionData.OperaReservation.IsBreakFastAvailable != null)
                        {
                            IsBreakFastAvailable = SessionData.OperaReservation.IsBreakFastAvailable.Value;
                        }
                        else if (reservations.IsBreakFastAvailable != null)
                        {
                            IsBreakFastAvailable = reservations.IsBreakFastAvailable.Value;
                        }
                        else
                        {
                            IsBreakFastAvailable = false;
                        }

                        reservationModel = new Models.ReservationModel()
                        {
                            ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                            ReservationID = reservations.ReservationDetailID,
                            AdultCount = reservations.Adultcount.HasValue ? reservations.Adultcount.Value : 0,
                            ArrivalDate = reservations.ArrivalDate.HasValue ? reservations.ArrivalDate.Value.ToString("dd MMM yyyy") : "",
                            AverageRoomRate = SessionData.OperaReservation.RateDetails.DailyRates[0].Amount,
                            ChildCount = reservations.Childcount.HasValue ? reservations.Childcount.Value : 0,
                            DepartureDate = reservations.DepartureDate.HasValue ? reservations.DepartureDate.Value.ToString("dd MMM yyyy") : "",
                            ExpectedTimeofArrival = ExpectedTimeofArrival,
                            FlightNo = reservations.FlightNo,
                            IsMembershipRequested = reservations.IsMemberShipEnrolled.HasValue ? reservations.IsMemberShipEnrolled.Value : false,
                            IsTermsAndConditions = false,
                            MembershipNo = reservations.MembershipNo,
                            ReservationNumber = reservations.ReservationNumber,
                            Profiles = profiles,
                            Questions = null,
                            RoomType = reservations.RoomType,
                            RoomTypeDescription = SessionData.OperaReservation.RoomDetails.RoomTypeDescription,
                            TotalRoomRate = TotalRoomRate,
                            IsDepositAvailable = reservations.IsDepositAvailable != null ? reservations.IsDepositAvailable.Value : false,
                            IsBreakFastAvailable = IsBreakFastAvailable,
                            IsUploadComplete = reservations.IsUploadComplete != null ? reservations.IsUploadComplete.Value : false,
                        };

                        QRCodeGenerator qrGenerator = new QRCodeGenerator();
                        QRCodeData qrCodeData = qrGenerator.CreateQrCode(confirmationNo, QRCodeGenerator.ECCLevel.Q);
                        QRCode qrCode = new QRCode(qrCodeData);
                        Bitmap qrCodeImage = qrCode.GetGraphic(20);

                        System.IO.MemoryStream ms = new MemoryStream();
                        qrCodeImage.Save(ms, ImageFormat.Jpeg);
                        byte[] byteImage = ms.ToArray();
                        var QRCodeBase64 = Convert.ToBase64String(byteImage);

                        ViewBag.QRcode = QRCodeBase64;

                        ViewBag.AdaptorAPIBaseURL = ConfigurationManager.AppSettings["AdaptorAPIBaseURL"].ToString();
                        ViewBag.CalQRcode = "";
                        Helpers.LogHelper.Instance.Log($"Reservation  {confirmationNo} successfully returned", $"{confirmationNo}", ActionName, ActionGroup);
                        return View(reservationModel);

                    }
                    else
                    {
                        Helpers.LogHelper.Instance.Warn($"Reservation {confirmationNo} already completed the pre-checkin, return reservation not found page", $"{confirmationNo}", ActionName, ActionGroup);
                        // Reservation not found page
                        return View("ReservationNotFound");
                    }
                }
                else
                {
                    Helpers.LogHelper.Instance.Warn($"Reservation not found for given confirmation no {confirmationNo}", $"{confirmationNo}", ActionName, ActionGroup);
                    // Reservation not found page
                    return View("ReservationNotFound");
                }
            }
            else
            {
                Helpers.LogHelper.Instance.Warn($"Reservation not found for given confirmation no {confirmationNo}", $"{confirmationNo}", ActionName, ActionGroup);
                return View("ReservationNotFound");
            }
        }

        public ActionResult ChangeLanguage(string currentLanguage, string confirmationToken)
        {
            //Set the UI culture baseon currentLanguage

            if (string.IsNullOrEmpty(currentLanguage))
                currentLanguage = "en";


            var cultureInfo = new CultureInfo(currentLanguage);
            //Thread.CurrentThread.CurrentUICulture = cultureInfo;
            Thread.CurrentThread.CurrentCulture = cultureInfo;
            //Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cultureInfo.Name);

            Session["SelectedLanguage"] = currentLanguage;

            if (Request.Cookies.AllKeys.Contains("culture"))
            {
                Request.Cookies.Remove("culture");
            }

            HttpCookie langCookie = new HttpCookie("culture", currentLanguage);
            langCookie.Expires = DateTime.Now.AddYears(1);
            langCookie.Path = "/";
            langCookie.Domain = Request.Url.Host;
            langCookie.Secure = false;

            Response.Cookies.Remove("culture");

            Response.SetCookie(langCookie);
            Response.Cookies.Add(langCookie);
            var x = $"{Request.Url.Scheme}://{Request.Url.Authority}/Home/Index?ID={HttpUtility.UrlEncode(confirmationToken)}";
            Response.Redirect(@x);
            return null;//RedirectToAction("Index", new { id = confirmationToken });
        }
        public async Task<ActionResult> IndexPayment(string id)
        {

            string ActionName = "IndexPayment", ActionGroup = "Pre-Checkin";
            // var test = Helpers.EncryptionHelper.EncryptString("41443868");
            if (string.IsNullOrEmpty(id))
            {
                return View("ReservationNotFound");
            }

            string confirmationNo = id;


            if (string.IsNullOrEmpty(confirmationNo))
            {
                return View("ReservationNotFound");
            }

            ViewBag.ReservationFound = false;
            ViewBag.PaymentProcessed = false;

            Models.ReservationModel reservationModel = new Models.ReservationModel();
            reservationModel.IsDepositAvailable = false;

            MastersLogics mastersLogics = new MastersLogics();

            var CountryList = await new CloudHelper().fetchcountryMaster(ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString(), ActionGroup);

            var reservationsDt = await new CloudHelper().FetchReservationDetailsByReferenceNumber(confirmationNo, new APIRequestModel { RequestObject = confirmationNo }, "", ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString());
            var reservations = new CloudReservationModel();
            if (reservationsDt?.responseData != null)
            {
                reservations = JsonConvert.DeserializeObject<List<CloudReservationModel>>(reservationsDt.responseData.ToString()).FirstOrDefault();

            }


            if (reservations != null)
            {
                var reservationfromopera = await new CloudHelper().fetchReservationFromPMS(new Models.OWS.OwsRequestModel()
                {
                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                    LegNumber = "1",
                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                    FetchBookingRequest = new Models.OWS.FetchBookingRequestModel()
                    {
                        ReservationNumber = confirmationNo

                    }
                }, ConfigurationManager.AppSettings["APIBaseUrl"].ToString(), "precheckin", ActionGroup);

                if (reservationfromopera != null && reservationfromopera.Count > 0)
                {

                    if (reservationfromopera.First().Adults != null && reservationfromopera.First().Adults.Value > 0)
                        SessionData.OperaReservation = reservationfromopera.First();

                    bool isredirectfromPaymentPage = false;
                    bool IsPaymentSuccess = false;
                    string PaymentFailureMessage = "";

                    if (TempData["IsredirectedfromPaymentPage"] != null)
                    {
                        isredirectfromPaymentPage = Convert.ToBoolean(TempData["IsredirectedfromPaymentPage"].ToString());
                        IsPaymentSuccess = Convert.ToBoolean(TempData["IsPaymentSuccess"].ToString());
                        PaymentFailureMessage = TempData["PaymentFailureMessage"].ToString();
                    }

                    ViewBag.IsredirectedfromPaymentPage = isredirectfromPaymentPage;
                    ViewBag.IsPaymentSuccess = IsPaymentSuccess;
                    ViewBag.PaymentFailureMessage = PaymentFailureMessage;

                    ViewBag.uploadcomplete = false;


                    if (reservations.IsPreCheckedInPMS.HasValue && !reservations.IsPreCheckedInPMS.Value || isredirectfromPaymentPage)
                    {
                        ViewBag.ReservationFound = true;

                        #region Get the existing selected package and Upsells

                        var ReservationPackagesList = reservationLogics.GetReservationPackages(reservations.ReservationDetailID);

                        if (ReservationPackagesList != null && ReservationPackagesList.Count > 0)
                        {
                            Helpers.LogHelper.Instance.Log($"Existing reservation packages found.", $"{confirmationNo}", ActionName, ActionGroup);

                            var RoomUpsellPackages = ReservationPackagesList.Where(x => x.IsRoomUpsell).Select(x => x.PackageID).ToArray();
                            var SpecialsPackages = ReservationPackagesList.Where(x => !x.IsRoomUpsell).Select(x => x.PackageID).ToArray();

                            ViewBag.RoomUpsellPackages = string.Join(",", RoomUpsellPackages);
                            ViewBag.SpecialPackages = string.Join(",", SpecialsPackages);
                            ViewBag.ReservationPackagesList = ReservationPackagesList;
                        }
                        else
                        {
                            Helpers.LogHelper.Instance.Log($"Existing reservation packages not found.", $"{confirmationNo}", ActionName, ActionGroup);
                            ViewBag.RoomUpsellPackages = string.Empty;
                            ViewBag.SpecialPackages = string.Empty;
                            ViewBag.ReservationPackagesList = new List<ReservationPackageModel>();
                        }
                        #endregion
                        #region VerifyVIPReservationOrNot
                        new LogHelper().Log("Verifying reservation VIP status in UDF field", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        if (SessionData.OperaReservation.userDefinedFields != null && SessionData.OperaReservation.userDefinedFields.Count > 0)
                        {
                            if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthUDF"].ToString())) != null &&
                                SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthUDF"].ToString())).FieldValue.Equals("NO"))
                            {
                                new LogHelper().Log("Reservation is flagged not to take payment", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                {
                    new Models.OWS.DepositDetail()
                    {
                        Amount = 0,
                        CardExpiryDate = null,
                        CreditCardNumber = null,
                        IsCreditCardDeposit = false,
                        PaymentType = null
                    }
                };
                                SessionData.OperaReservation.IsDepositAvailable = true;
                            }
                            else if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthAmntUDF"])) != null &&
                                SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthAmntUDF"])).FieldValue.Equals("NO"))
                            {

                                new LogHelper().Log("Reservation is flagged not to take payment", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                        {
                            new Models.OWS.DepositDetail()
                            {
                                Amount = 0,
                                CardExpiryDate = null,
                                CreditCardNumber = null,
                                IsCreditCardDeposit = false,
                                PaymentType = null
                            }
                        };

                                SessionData.OperaReservation.IsDepositAvailable = true;
                            }
                        }
                        new LogHelper().Log("Verifying reservation VIP status in UDF field completed", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        #endregion

                        #region PaymentDesabling
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings
                    ["IsPaymentDisabled"]))
                        {
                            new LogHelper().Log("Disabling the payment as per the config", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                {
                    new Models.OWS.DepositDetail()
                    {
                        Amount = 0,
                        CardExpiryDate = null,
                        CreditCardNumber = null,
                        IsCreditCardDeposit = false,
                        PaymentType = null
                    }
                };
                            SessionData.OperaReservation.IsDepositAvailable = true;
                        }
                        #endregion

                        #region Update ETA
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsETADefault"]))
                        {
                            new LogHelper().Log("Assigning NULL value to ETA as per the config", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            SessionData.OperaReservation.ExpectedArrivalTime = null;
                        }
                        #endregion

                        #region Processing RoomRate
                        new LogHelper().Log("Updating rate details", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        if (SessionData.OperaReservation.RateDetails != null && SessionData.OperaReservation.RateDetails.DailyRates != null && SessionData.OperaReservation.RateDetails.DailyRates.Count > 0)
                        {
                            decimal total_roomrate = SessionData.OperaReservation.RateDetails.DailyRates.Sum(x => x.Amount);
                            if (SessionData.OperaReservation.PrintRate != null && SessionData.OperaReservation.PrintRate.Value)
                                SessionData.OperaReservation.RateDetails.RateAmount = total_roomrate;
                            else
                                SessionData.OperaReservation.TotalAmount = 0;
                            new LogHelper().Log("Updating rate details completed", SessionData.OperaReservation.ReservationNameID, "Index", "Pre-Checkin");
                        }
                        else
                            new LogHelper().Log("Updating rate details failed because Rate details are blank in the reservation", SessionData.OperaReservation.ReservationNameID, "Index", "Pre-Checkin");
                        #endregion


                        #region Processing MealPlan
                        if (ConfigurationManager.AppSettings["IsBreakFastValidationWithUDF"] != null && Convert.ToBoolean(ConfigurationManager.AppSettings["IsBreakFastValidationWithUDF"]))
                        {
                            new LogHelper().Debug("Processing meal plan from UDF fields", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            if (SessionData.OperaReservation.userDefinedFields != null && SessionData.OperaReservation.userDefinedFields.Count > 0)
                            {
                                if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])) != null)
                                {

                                    if (!SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])).FieldValue.Equals("NP"))
                                    {
                                        string tempUDFValue = SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])).FieldValue;
                                        if (!string.IsNullOrEmpty(tempUDFValue))
                                        {
                                            bool isPackageFound = false;
                                            if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(tempUDFValue))
                                                isPackageFound = true;
                                            if (isPackageFound)
                                            {
                                                SessionData.OperaReservation.IsBreakFastAvailable = true;
                                                new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                            }
                                        }
                                    }
                                    else
                                        new LogHelper().Log("Processing meal plan not updated (NP not present in UDF)", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup); ;
                                }
                            }
                            else
                                new LogHelper().Log("No UDF fields for meal plan not found", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        }
                        if (ConfigurationManager.AppSettings["IsBreakFastValidationWithPackage"] != null && Convert.ToBoolean(ConfigurationManager.AppSettings["IsBreakFastValidationWithPackage"]))
                        {
                            new LogHelper().Debug("Processing package list in the reservation for meal plan", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            if (((SessionData.OperaReservation.PackageDetails != null && SessionData.OperaReservation.PackageDetails.Count > 0) || (SessionData.OperaReservation.PreferanceDetails != null && SessionData.OperaReservation.PreferanceDetails.Count > 0)) && (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["PackageCodes"]) && ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList() != null))
                            {
                                if (SessionData.OperaReservation.PackageDetails != null && SessionData.OperaReservation.PackageDetails.Count > 0)
                                {
                                    bool isPackageFound = false;
                                    foreach (Models.OWS.PackageDetails package in SessionData.OperaReservation.PackageDetails)
                                    {
                                        if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(package.PackageCode))
                                        {
                                            isPackageFound = true;
                                            break;
                                        }
                                    }
                                    if (isPackageFound)
                                    {
                                        SessionData.OperaReservation.IsBreakFastAvailable = true;
                                        new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                    }
                                }
                                if (SessionData.OperaReservation.PreferanceDetails != null && SessionData.OperaReservation.PreferanceDetails.Count > 0)
                                {
                                    if (SessionData.OperaReservation.IsBreakFastAvailable == null || !SessionData.OperaReservation.IsBreakFastAvailable.Value)
                                    {
                                        bool isPrefernceFound = false;
                                        foreach (Models.OWS.PreferanceDetails prefernce in SessionData.OperaReservation.PreferanceDetails)
                                        {
                                            if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(prefernce.PreferanceCode))
                                            {
                                                isPrefernceFound = true;
                                                break;
                                            }
                                        }
                                        if (isPrefernceFound)
                                        {
                                            SessionData.OperaReservation.IsBreakFastAvailable = true;
                                            new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                        }
                                    }
                                }
                            }
                            else
                                new LogHelper().Log("No package or prefernce list in the reservation for meal plan not found", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        }
                        #endregion
                        if ((reservations.IsEcomchekinPaymentStaus != null && reservations.IsEcomchekinPaymentStaus.Value) || isredirectfromPaymentPage)
                        {
                            Helpers.LogHelper.Instance.Log($"Reservation #{confirmationNo} payment already done.", $"{confirmationNo}", ActionName, ActionGroup);
                            ViewBag.PaymentProcessed = true;
                            ViewBag.IsPaymentSuccess = true;
                        }

                        // var Questions = reservationLogics.GetQuestions();
                        var PackageLists = reservationLogics.GetPackages(SessionData.OperaReservation.RoomDetails.RoomType);
                        ViewBag.PackageList = PackageLists;
                        // ViewBag.Questions = Questions;

                        

                        Helpers.LogHelper.Instance.Log($"Getting prfile details", $"{confirmationNo}", ActionName, ActionGroup);
                        var ProfileList = await reservationLogics.GetReservationProfileList(reservations.ReservationDetailID);

                        ViewBag.Profiles = ProfileList;
                        ViewBag.CountryList = new SelectList(CountryList, "CountryMasterID", "Country_Full_name", ProfileList[0].CountryMasterID);

                        if (ProfileList[0].CountryMasterID != null)
                        {
                            var StateList = mastersLogics.GetStateListByCountryID(ProfileList[0].CountryMasterID.Value);
                            ViewBag.StateList = new SelectList(StateList, "StateMasterID", "Statename", ProfileList[0].StateMasterID);
                        }
                        else
                        {
                            List<Models.StateMaster> tbstateMasters = new List<Models.StateMaster>();
                            tbstateMasters.Add(new Models.StateMaster()
                            {
                                Statename = "Please select country",
                                StateMasterID = -1

                            });
                            ViewBag.StateList = new SelectList(tbstateMasters, "StateMasterID", "Statename", "Select State");

                        }
                        CountryList.Add(new tbCountryMaster()
                        {
                            CountryMasterID = -1,
                            Country_Full_name = "Please select nationality"
                        });
                        ViewBag.NationalityList = new SelectList(CountryList, "CountryMasterID", "Country_Full_name", "Please select nationality");




                        List<Models.Profile> profiles = new List<Models.Profile>();
                        int i = 0;
                        foreach (var profile in ProfileList)
                        {
                            if (profile.DocumentImage1 != null)
                            {
                                if (profile.DocumentImage1.Length > 0)
                                {
                                    i++;
                                }
                                else if (!string.IsNullOrEmpty(profile.DocumentNumber) && profile.DocumentNumber.Length > 0)
                                {
                                    i++;
                                }
                            }
                            else if (!string.IsNullOrEmpty(profile.DocumentNumber) && profile.DocumentNumber.Length > 0)
                            {
                                i++;
                            }
                            profiles.Add(new Models.Profile()
                            {
                                AddressLine1 = profile.AddressLine1,
                                AddressLine2 = profile.AddressLine2,
                                City = profile.City,
                                CountryID = profile.CountryMasterID,
                                Email = profile.Email,
                                FirstName = profile.FirstName,
                                LastName = profile.LastName,
                                Phone = profile.Phone,
                                PostalCode = profile.PostalCode != null ? profile.PostalCode : "",
                                StateID = profile.StateMasterID,
                                ProfileDetailID = profile.ProfileDetailID,
                                ProfileID = Convert.ToInt32(profile.ProfileID ?? "0"),
                                MiddleName = profile.MiddleName,
                                DocumentImage1 = profile.DocumentImage1 != null ? "0" : "1"
                            });
                        }
                        if (profiles != null)
                        {
                            if (profiles.Count() > 0 && profiles.Count() == i)
                            {
                                reservationLogics.UpdateReservationByStage("Upload Completes", new UpdateReservationModel()
                                {
                                    ReservationID = reservations.ReservationDetailID
                                });
                                ViewBag.uploadcomplete = true;
                                reservations.IsUploadComplete = true;
                            }
                        }

                        decimal TotalRoomRate = 0;
                        TotalRoomRate = SessionData.OperaReservation.TotalAmount.HasValue ? SessionData.OperaReservation.TotalAmount.Value : 0;


                        string ExpectedTimeofArrival = "";

                        if (reservations.ETA.HasValue && !(reservations.ETA.Value.ToString("HH:mm") == "00:00"))
                        {
                            Helpers.LogHelper.Instance.Log($"Estimate time of arrival already exist {reservations.ETA.Value.ToString("HH:mm")} ", $"{confirmationNo}", ActionName, ActionGroup);
                            DateTime timeUtc = reservations.ETA.Value;
                            ExpectedTimeofArrival = Helpers.DateTimeHelper.ConvertFromUTC(timeUtc);
                        }

                        //Added For breakfast included
                        bool IsBreakFastAvailable;
                        if (SessionData.OperaReservation.IsBreakFastAvailable != null)
                        {
                            IsBreakFastAvailable = SessionData.OperaReservation.IsBreakFastAvailable.Value;
                        }
                        else if (reservations.IsBreakFastAvailable != null)
                        {
                            IsBreakFastAvailable = reservations.IsBreakFastAvailable.Value;
                        }
                        else
                        {
                            IsBreakFastAvailable = false;
                        }

                        reservationModel = new Models.ReservationModel()
                        {
                            ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                            ReservationID = reservations.ReservationDetailID,
                            AdultCount = reservations.Adultcount.HasValue ? reservations.Adultcount.Value : 0,
                            ArrivalDate = reservations.ArrivalDate.HasValue ? reservations.ArrivalDate.Value.ToString("dd MMM yyyy") : "",
                            AverageRoomRate = SessionData.OperaReservation.RateDetails.DailyRates[0].Amount,
                            ChildCount = reservations.Childcount.HasValue ? reservations.Childcount.Value : 0,
                            DepartureDate = reservations.DepartureDate.HasValue ? reservations.DepartureDate.Value.ToString("dd MMM yyyy") : "",
                            ExpectedTimeofArrival = ExpectedTimeofArrival,
                            FlightNo = reservations.FlightNo,
                            IsMembershipRequested = reservations.IsMemberShipEnrolled.HasValue ? reservations.IsMemberShipEnrolled.Value : false,
                            IsTermsAndConditions = false,
                            MembershipNo = reservations.MembershipNo,
                            ReservationNumber = reservations.ReservationNumber,
                            Profiles = profiles,
                            Questions = null,
                            RoomType = reservations.RoomType,
                            RoomTypeDescription = SessionData.OperaReservation.RoomDetails.RoomTypeDescription,
                            TotalRoomRate = TotalRoomRate,
                            IsDepositAvailable = reservations.IsDepositAvailable != null ? reservations.IsDepositAvailable.Value : false,
                            IsBreakFastAvailable = IsBreakFastAvailable,
                            IsUploadComplete = reservations.IsUploadComplete != null ? reservations.IsUploadComplete.Value : false,
                        };

                        QRCodeGenerator qrGenerator = new QRCodeGenerator();
                        QRCodeData qrCodeData = qrGenerator.CreateQrCode(confirmationNo, QRCodeGenerator.ECCLevel.Q);
                        QRCode qrCode = new QRCode(qrCodeData);
                        Bitmap qrCodeImage = qrCode.GetGraphic(20);

                        System.IO.MemoryStream ms = new MemoryStream();
                        qrCodeImage.Save(ms, ImageFormat.Jpeg);
                        byte[] byteImage = ms.ToArray();
                        var QRCodeBase64 = Convert.ToBase64String(byteImage);

                        ViewBag.QRcode = QRCodeBase64;

                        ViewBag.AdaptorAPIBaseURL = ConfigurationManager.AppSettings["AdaptorAPIBaseURL"].ToString();
                        ViewBag.CalQRcode = "";
                        Helpers.LogHelper.Instance.Log($"Reservation  {confirmationNo} successfully returned", $"{confirmationNo}", ActionName, ActionGroup);
                        return View("Index",reservationModel);

                    }
                    else
                    {
                        Helpers.LogHelper.Instance.Warn($"Reservation {confirmationNo} already completed the pre-checkin, return reservation not found page", $"{confirmationNo}", ActionName, ActionGroup);
                        // Reservation not found page
                        return View("ReservationNotFound");
                    }
                }
                else
                {
                    Helpers.LogHelper.Instance.Warn($"Reservation not found for given confirmation no {confirmationNo}", $"{confirmationNo}", ActionName, ActionGroup);
                    // Reservation not found page
                    return View("ReservationNotFound");
                }
            }
            else
            {
                Helpers.LogHelper.Instance.Warn($"Reservation not found for given confirmation no {confirmationNo}", "", ActionName, ActionGroup);
                // Reservation not found page
                return View("ReservationNotFound");
            }

        }

        public async Task<ActionResult> UpdateReservation(Models.ReservationModel reservationModel)
        {
            string ActionName = "UpdateReservation", ActionGroup = "PreCheckin";
            try
            {

                int count = 0;
                ReservationLogics reservationLogics = new ReservationLogics();
                var localResponse = new APIResponseModel();
                //push events to DB
                reservationLogics.InsertEvent(reservationModel.ReservationID, "Guest Details");

                SessionData.OperaReservation.FlightNo = reservationModel.FlightNo;
                SessionData.OperaReservation.ETA = Helpers.DateTimeHelper.ConvertToUTCDatetime(reservationModel.ExpectedTimeofArrival);
                SessionData.OperaReservation.ExpectedArrivalTime = Helpers.DateTimeHelper.ConvertToUTCDatetime(reservationModel.ExpectedTimeofArrival);

                if (SessionData.OperaReservation != null)
                {
                    foreach (var profile in reservationModel.Profiles)
                    {
                        if (SessionData.OperaReservation != null && SessionData.OperaReservation.GuestProfiles != null && SessionData.OperaReservation.GuestProfiles.Count > 0)
                        {
                            var matchingGuestProfile = SessionData.OperaReservation.GuestProfiles.FirstOrDefault(gp => gp.PmsProfileID == profile.ProfileID.ToString());
                            DateTime parsedDateOfBirth;
                            if (DateTime.TryParseExact(profile.DateOfBirth, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out parsedDateOfBirth))
                            {
                                // Convert parsedDateOfBirth to 'yyyy-MM-dd' format and assign it to BirthDate
                                matchingGuestProfile.BirthDate = parsedDateOfBirth.ToString("yyyy-MM-dd");
                            }

                           
                            #region Update email in opera reservation 
                            var reservationEmail = getPrimaryEmail();
                            if (string.IsNullOrEmpty(reservationEmail))
                            {
                                SessionData.OperaReservation.GuestProfiles.First().Email = new List<Models.OWS.Email>()
                                {
                                    new Models.OWS.Email()
                                    {
                                        displaySequence = 1,
                                        email = profile.Email,
                                        emailType = "EMAIL",
                                        primary = true
                                    }
                                };

                                #region Update to PMS
                                await CloudHelper.updateGuestProfileInPMS(new OWSRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings
                        ["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings
                        ["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings
                        ["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings
                        ["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings
                        ["SystemType"].ToString(),
                                    UpdateProileRequest = new Models.UpdateProfile()
                                    {
                                        Emails = new List<Models.Email>()
                            {
                                new Models.Email()
                                {
                                    displaySequence = 1,
                                    email = profile.Email,
                                    emailType ="EMAIL",
                                    primary = true
                                }
                            },
                                        ProfileID = SessionData.OperaReservation.GuestProfiles.First().PmsProfileID
                                    }
                                }, "UpdateEmailList", ConfigurationManager.AppSettings
                        ["APIBaseUrl"].ToString(), ActionGroup);
                                #endregion
                            }
                            else if (reservationEmail != profile.Email)
                            {
                                var emailIndex = SessionData.OperaReservation.GuestProfiles.First().Email.FindIndex(x => x.email.Equals(reservationEmail));
                                if (emailIndex >= 0)
                                {
                                    if (SessionData.OperaReservation.GuestProfiles.First().Email[emailIndex] != null)
                                    {
                                        SessionData.OperaReservation.GuestProfiles.First().Email[emailIndex].primary = false;
                                    }
                                }

                                SessionData.OperaReservation.GuestProfiles.First().Email = new List<Models.OWS.Email>()
                    {
                        new Models.OWS.Email()
                        {
                            displaySequence = 1,
                            email = profile.Email,
                            emailType = "EMAIL",
                            primary = true
                        }
                    };

                                #region Update to PMS
                                await CloudHelper.updateGuestProfileInPMS(new OWSRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings
                             ["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings
                             ["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings
                             ["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings
                             ["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings
                             ["SystemType"].ToString(),
                                    UpdateProileRequest = new Models.UpdateProfile()
                                    {

                                        Emails = new List<Models.Email>()
                            {
                                new Models.Email()
                                {
                                    displaySequence = 1,
                                    email = profile.Email,
                                    emailType = "EMAIL",
                                    primary = true
                                }
                            },
                                        ProfileID = SessionData.OperaReservation.GuestProfiles.First().PmsProfileID
                                    }
                                }, "UpdateEmailList", ConfigurationManager.AppSettings
                        ["APIBaseUrl"].ToString(), ActionGroup);
                                #endregion
                            }
                            #endregion

                            #region Update phone in opera reservation stored in session
                            var reservationPhone = getPrimaryPhone();
                            if (string.IsNullOrEmpty(reservationPhone))
                            {
                                SessionData.OperaReservation.GuestProfiles.First().Phones = new List<Models.OWS.Phone>()
                                {
                                    new Models.OWS.Phone()
                                    {
                                        displaySequence = 1,
                                        PhoneNumber = profile.Phone,
                                        phoneRole = "HOME",
                                        phoneType = "PHONE",
                                        primary = true
                                    }
                                };

                                #region Update to PMS
                                await CloudHelper.updateGuestProfileInPMS(new OWSRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings
                            ["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings
                            ["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings
                            ["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings
                            ["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings
                            ["SystemType"].ToString(),
                                    UpdateProileRequest = new Models.UpdateProfile()
                                    {
                                        Phones = new List<Models.Phone>()
                            {
                                new Models.Phone()
                                {
                                    displaySequence = 1,
                            PhoneNumber = profile.Phone,
                            phoneRole = "HOME",
                            phoneType = "PHONE",
                            primary = true
                                }
                            },
                                        ProfileID = SessionData.OperaReservation.GuestProfiles.First().PmsProfileID
                                    }
                                }, "UpdatePhoneList", ConfigurationManager.AppSettings
                        ["APIBaseUrl"].ToString(), ActionGroup);
                                #endregion
                            }
                            else if (reservationPhone != profile.Phone)
                            {
                                var phoneIndex = SessionData.OperaReservation.GuestProfiles.First().Phones.FindIndex(x => x.PhoneNumber.Equals(reservationPhone));
                                if (phoneIndex >= 0)
                                {
                                    if (SessionData.OperaReservation.GuestProfiles.First().Phones[phoneIndex] != null)
                                    {
                                        SessionData.OperaReservation.GuestProfiles.First().Phones[phoneIndex].primary = false;
                                    }
                                }

                                SessionData.OperaReservation.GuestProfiles.First().Phones = new List<Models.OWS.Phone>()
                    {
                        new Models.OWS.Phone()
                        {
                            displaySequence = 1,
                            PhoneNumber = profile.Phone,
                            phoneRole = "HOME",
                            phoneType = "PHONE",
                            primary = true
                        }
                    };

                                #region Update to PMS
                                await CloudHelper.updateGuestProfileInPMS(new OWSRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings
                        ["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings
                        ["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings
                        ["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings
                        ["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings
                        ["SystemType"].ToString(),
                                    UpdateProileRequest = new Models.UpdateProfile()
                                    {
                                        Phones = new List<Models.Phone>()
                            {
                                new Models.Phone()
                        {
                            displaySequence = 1,
                            PhoneNumber = profile.Phone,
                            phoneRole = "HOME",
                            phoneType = "PHONE",
                            primary = true
                        }
                            },
                                        ProfileID = SessionData.OperaReservation.GuestProfiles.First().PmsProfileID
                                    }
                                }, "UpdatePhoneList", ConfigurationManager.AppSettings
                        ["APIBaseUrl"].ToString(), ActionGroup);
                                #endregion
                            }
                            #endregion

                            #region Address

                            if (SessionData.OperaReservation.GuestProfiles.First().Address != null && SessionData.OperaReservation.GuestProfiles.First().Address.Count > 0)
                            {
                                var UpdateProileRequest = new Models.UpdateProfile()
                                {
                                    ProfileID = SessionData.OperaReservation.GuestProfiles.FirstOrDefault().PmsProfileID,
                                    Addresses = new List<Models.Address>()
                                        {
                                            new Models.Address()
                                            {
                                                address1 = profile.AddressLine1,
                                                address2 = profile.AddressLine2,
                                                city = profile.City,
                                                state = profile.StateID!=null?GetStatelist         (profile.StateID.Value):null,
                                country = GetCountry(profile.CountryID.Value),
                                zip = profile.PostalCode,
                                                displaySequence = 1,
                                                primary = true,
                                                addressType = "BUSINESS"
                                            }
                                        }
                                };
                                #region Address 
                                new LogHelper().Log("Updating address in opera  - (Last name - +" + SessionData.OperaReservation.GuestProfiles.First().LastName + ")", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                Models.OwsResponseModel owsResponse = await CloudHelper.UpdateProfileAddressAsync(SessionData.OperaReservation.ReservationNameID, new OWSRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings
                        ["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings
                        ["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings
                        ["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings
                        ["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings
                        ["SystemType"].ToString(),
                                    UpdateProileRequest = UpdateProileRequest
                                }, "pre checked-in fetch", ConfigurationManager.AppSettings
                        ["APIBaseUrl"].ToString());

                                if (!owsResponse.result)
                                {
                                    new LogHelper().Log("Failled to update address info with reason :- " + owsResponse.responseMessage, "", ActionName, ActionGroup);
                                    new LogHelper().Warn("Failled to update address info with reason :- " + owsResponse.responseMessage, "", ActionName, ActionGroup);
                                }
                                else
                                {
                                    new LogHelper().Log("Updated address successfully", "", ActionName, ActionGroup);
                                }

                                #endregion
                            }
                            #endregion
                           
                        }
                    }

                }

                var localAPIResponse = await new CloudHelper().updateReservationDetailsInLocalDB(new APIRequestModel()
                {
                    RequestObject = new List<Models.OWS.OperaReservation> { SessionData.OperaReservation },
                    SyncFromCloud = false
                    //changed to false by jeena on 1072023
                }, ConfigurationManager.AppSettings
                    ["APIBaseUrl"], ActionGroup);

                #region Updating reservation additional details locally

                new LogHelper().Debug("Pushing reservation additional details to local DB", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);



                List<ReservationAdditionalDetails> additionalDetails = new List<ReservationAdditionalDetails>();
                additionalDetails.Add(new ReservationAdditionalDetails
                {
                    FieldName = "Place Of Birth",
                    FIeldValue = reservationModel.Profiles[0].PlaceOfBirth,
                    ResID = SessionData.OperaReservation.ReservationNameID

                });
                additionalDetails.Add(new ReservationAdditionalDetails
                {
                    FieldName = "Place Of Issue",
                    FIeldValue = reservationModel.Profiles[0].placeofissue,
                    ResID = SessionData.OperaReservation.ReservationNameID

                });

                localResponse = await new CloudHelper().PushReservationAdditionalDetails(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                {
                    RequestObject = additionalDetails
                }, "pre checked-in fetch", ConfigurationManager.AppSettings
                   ["APIBaseUrl"]);
                if (!localResponse.result)
                {
                    new LogHelper().Log("Failled to push reservation policy with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                    new LogHelper().Warn("Failled to update reservation policy with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                }
                else
                    new LogHelper().Debug("reservation policy updated successfully", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);


                #endregion
                Helpers.LogHelper.Instance.Log($"Updating reservation/guest details,", $"{reservationModel.ReservationNumber}", ActionName, ActionGroup);


                return Json(new { result = count > 0 });
            }
            catch (Exception ex)
            {
                Helpers.LogHelper.Instance.Error(ex, $"{reservationModel.ReservationNumber}", ActionName, ActionGroup);
                return Json(new { result = false });
            }


        }

        public async Task<ActionResult> UpdatePolicies(PoliciesModel policiesModel)
        {
            int count = 0;
            string RegcardBase64 = null;
            //push events to DB
            string ActionName = "UpdatePolicies", ActionGroup = "Pre-Checkin";
            reservationLogics.InsertEvent(policiesModel.ReservationID, "Registration Card");

            Helpers.LogHelper.Instance.Log($"Updating Signature,", $"{policiesModel.ReservationID}", "UpdatePolicies", "Pre-Checkin");



            #region signature update
            #region Pushing Guest Signature to Local DB
            if (!string.IsNullOrEmpty(policiesModel.Base64Signature))
            {
                try
                {
                    new LogHelper().Log("Pushing guest signature to Local DB", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    byte[] guestSignature = null;
                    guestSignature = Convert.FromBase64String(policiesModel.Base64Signature);
                    var localResponse = await new CloudHelper().InsertReservationDocuments("", new Models.APIRequestModel()
                    {
                        RequestObject = new List<Models.ReservationDocumentsDataTableModel>()
                                {
                                    new Models.ReservationDocumentsDataTableModel()
                                    {
                                        Document = guestSignature,
                                        DocumentType = "Signature",
                                        ReservationNameID = SessionData.OperaReservation.ReservationNameID
                                    }
                                }
                    }, "pre checked-in fetch", ConfigurationManager.AppSettings
                     ["APIBaseUrl"].ToString());
                    if (!localResponse.result)
                    {
                        new LogHelper().Log("Failled to push guest signature with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                        new LogHelper().Warn("Failled to push guest signature with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    }
                    else
                    {
                        new LogHelper().Log("Signature updated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    }
                }
                catch (Exception exc)
                {
                    new LogHelper().Error(exc, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
            }
            #endregion

            #region Get Regcard

            try
            {

                if (SessionData.OperaReservation != null)
                {
                    new LogHelper().Log("Generating registration card", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    if (string.IsNullOrEmpty(policiesModel.Base64Signature))
                        new LogHelper().Log("Guest signature missing", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    SessionData.OperaReservation.GuestSignature = !string.IsNullOrEmpty(policiesModel.Base64Signature) ? policiesModel.Base64Signature : "";
                    Models.OWS.OwsResponseModel regcardResponse = await new CloudHelper().GetRegistrationCard(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                    {
                        ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                        DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                        DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                        HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                        KioskID = ConfigurationManager.AppSettings
                    ["KioskID"].ToString(),
                        LegNumber = "1",
                        Language = ConfigurationManager.AppSettings
                    ["Language"].ToString(),
                        Password = ConfigurationManager.AppSettings
                    ["Password"].ToString(),
                        Username = ConfigurationManager.AppSettings
                    ["Username"].ToString(),
                        SystemType = ConfigurationManager.AppSettings
                    ["SystemType"].ToString(),
                        OperaReservation = SessionData.OperaReservation
                    }, "pre checked-in fetch", ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString());

                    if (!regcardResponse.result || regcardResponse.responseData == null)
                    {
                        new LogHelper().Log("Failled to generate regcard with reason :- " + regcardResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                        new LogHelper().Warn("Failled to generate regcard with reason :- " + regcardResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    }
                    else
                    {
                        new LogHelper().Log("Regcard generated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                        RegcardBase64 = regcardResponse.responseData.ToString();
                    }
                }
                else
                {
                    new LogHelper().Log("Failled to generating registration card, failled to get opera reservation", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to generating registration card, failled to get opera reservation", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
            }
            catch (Exception ex)
            {
                new LogHelper().Error(ex, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
            }
            #endregion

            #region Pushing regcard to Local DB
            if (!string.IsNullOrEmpty(RegcardBase64))
            {
                try
                {
                    new LogHelper().Log("Pushing registration card to Local DB", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    byte[] regCard = null;
                    regCard = Convert.FromBase64String(RegcardBase64);
                    var localResponse = await new CloudHelper().InsertReservationDocuments("", new Models.APIRequestModel()
                    {
                        RequestObject = new List<Models.ReservationDocumentsDataTableModel>()
                                {
                                    new Models.ReservationDocumentsDataTableModel()
                                    {
                                        Document = regCard,
                                        DocumentType = "Registration Card",
                                        ReservationNameID =SessionData.OperaReservation.ReservationNameID
                                    }
                                }
                    }, "pre checked-in fetch", ConfigurationManager.AppSettings
                     ["APIBaseUrl"].ToString());
                    if (!localResponse.result)
                    {
                        new LogHelper().Log("Failled to push reservation document with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                        new LogHelper().Warn("Failled to push reservation document with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    }
                    else
                    {
                        new LogHelper().Log("Reservation document updated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    }
                }
                catch (Exception exc)
                {
                    new LogHelper().Error(exc, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
            }
            #endregion
            #endregion
            List<ReservationPolicyModel> reservationPolicyTable = new List<ReservationPolicyModel>();
            var policymasterist = await new CloudHelper().fetchPolicyMaster(ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString(), ActionGroup);
            if (policiesModel.CheckBox1.Value)
            {
                var policyModel = policymasterist == null ? null : policymasterist.Where(x => x.PolicyType == "CheckBox1").FirstOrDefault();
                if (policyModel != null && !string.IsNullOrEmpty(policyModel.PolicyDescription) && policyModel.PolicyDescription.ToLower().Contains("marketing")
                   )
                {
                    Models.ReservationPolicyModel reservationPolicy = new Models.ReservationPolicyModel()
                    {
                        IsRoomUpsell = false,
                        PackageCode = null,
                        PackageDescription = null,
                        ReqStatus = true,
                        RequestType = "Marketing Email",
                        ReservationNameID = SessionData.OperaReservation.ReservationNameID.ToString(),
                        UserID = 0
                    };
                    reservationPolicyTable.Add(reservationPolicy);

                }
            }

            if (reservationPolicyTable != null && reservationPolicyTable.Count > 0)
            {
                var localResponse = await new CloudHelper().PushReservationPolicies(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                {
                    RequestObject = reservationPolicyTable
                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                if (!localResponse.result)
                {
                    new LogHelper().Log("Failled to push reservation policy with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to update reservation policy with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
                else
                    new LogHelper().Log("reservation policy updated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
            }

            return Json(new { result = count > 0 });
        }

        public async Task<ActionResult> savePackages(int ReservationID, string Packages)
        {
            var PackageMAsterLists = reservationLogics.GetPackages(SessionData.OperaReservation.RoomDetails.RoomType);
            int count = 1;
            List<Models.UpsellPackageModel> upsellPackages =
            new List<Models.UpsellPackageModel>();
            var packageList = Packages.Split(',');

            if (packageList.Count() > 0 && PackageMAsterLists.Count > 0)
            {
                foreach (var packages in packageList)
                {
                    var package = PackageMAsterLists.Where(x => x.PackageID.ToString() == packages).FirstOrDefault();
                    upsellPackages.Add(new Models.UpsellPackageModel() { ReservationNameID = SessionData.OperaReservation.ReservationNameID, PackageAmount = package.PackageAmount.Value.ToString(), PackageCode = package.PackageCode, PackageDesc = package.PackageDesc, PackageName = package.PackageName, IsRoomUpsell = package.IsRoomUpsell });
                }

            }

            #region Updating upsell package locally
            new LogHelper().Log("Pushing upsell selected to local DB", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
            var localResponse = await new CloudHelper().PushUpsellpackages("", new Models.APIRequestModel()
            {
                RequestObject = upsellPackages
            }, "pre checked-in fetch", ConfigurationManager.AppSettings
                     ["APIBaseUrl"].ToString());
            if (!localResponse.result)
            {
                new LogHelper().Log("Failled to update upsell with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                new LogHelper().Warn("Failled to update upsell with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
            }
            else
                new LogHelper().Log("Upsell updated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
            #endregion

            return Json(new { result = count > 0 });
        }

        public async Task<ActionResult> UploadDocument(UploadGuestDocumentModel uploadGuestDocumentModel)
        {
            var files = Request.Files;
           
            int count = 0;

            //push events to DB
            reservationLogics.InsertEvent(uploadGuestDocumentModel.ReservationID, "DocumentUploadTry");
            Helpers.LogHelper.Instance.Log($"Uploading guest document,", $"{uploadGuestDocumentModel.ReservationID}", "UploadDocument", "Pre-Checkin");


            var documentModel = new UpdateReservationModel();

            if (uploadGuestDocumentModel.documentInformation != null)
            {
                var docInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<DocumentInformation>(uploadGuestDocumentModel.documentInformation);
                if (docInfo != null)
                {
                    DateTime expiryDate = new DateTime(1900, 01, 01);
                    DateTime issueDate = new DateTime(1900, 01, 01);
                    DateTime birthDate = new DateTime(1900, 01, 01);

                    if (!DateTime.TryParseExact(docInfo.issueDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out issueDate))
                    {
                        issueDate = new DateTime(1900, 01, 01);
                    }
                    if (!DateTime.TryParseExact(docInfo.expiryDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out expiryDate))
                    {
                        expiryDate = new DateTime(1900, 01, 01);
                    }
                    if (!DateTime.TryParseExact(docInfo.birthDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out birthDate))
                    {
                        birthDate = new DateTime(1900, 01, 01);
                    }

                    documentModel.Gender = docInfo.gender;
                    documentModel.IssueCountry = docInfo.issueCountry;
                    documentModel.ExpiryDate = expiryDate;
                    documentModel.IssueDate = issueDate;
                    documentModel.DocumentType = docInfo.documentType;
                    documentModel.DocumentNumber = docInfo.documentNumber;
                    documentModel.BirthDate = birthDate;
                    documentModel.Nationality = docInfo.nationality;

                    documentModel.FirstName = docInfo.firstName;
                    documentModel.MiddleName = docInfo.middleName;
                    documentModel.LastName = docInfo.lastName;

                    if (!string.IsNullOrEmpty(docInfo.faceImage))
                    {
                        documentModel.FaceImage = Convert.FromBase64String(docInfo.faceImage);
                    }

                }
            }

            documentModel.ReservationID = uploadGuestDocumentModel.ReservationID;
            documentModel.ProfileDetailID = uploadGuestDocumentModel.ProfileDetailID;


            //documentModel.DocumentImage1 = Request.Files[0].InputStream


            if (!string.IsNullOrEmpty(uploadGuestDocumentModel.Doc1Base64))
            {
                documentModel.DocumentImage1 = Convert.FromBase64String(uploadGuestDocumentModel.Doc1Base64);
            }

            if (!string.IsNullOrEmpty(uploadGuestDocumentModel.Doc2Base64))
            {
                documentModel.DocumentImage2 = Convert.FromBase64String(uploadGuestDocumentModel.Doc2Base64);
            }

            Helpers.LogHelper.Instance.Debug($"Uploading Document Json : {Newtonsoft.Json.JsonConvert.SerializeObject(documentModel)}", $"{uploadGuestDocumentModel.ReservationID}", "UploadDocument", "Pre-Checkin");
            if (string.IsNullOrEmpty(uploadGuestDocumentModel.ProfileID) || uploadGuestDocumentModel.ProfileID=="0")
            {
                new LogHelper().Log("Creating accompanying profile in opera  - (Last name - +" + documentModel.LastName + ")", documentModel.ReservationID.ToString(), "FetchPreCheckedInReservation", "pre checked-in fetch");
                Models.OWS.OwsResponseModel responseModel = await new CloudHelper().CreateAccompanyingProfile(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                {
                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                    LegNumber = "1",
                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                    Username = ConfigurationManager.AppSettings["Username"].ToString(),



                    CreateAccompanyingProfileRequest = new Models.OWS.CreateAccompanyingProfileRequest()
                    {
                        FirstName = documentModel.FirstName,
                        MiddleName = documentModel.MiddleName,
                        LastName = documentModel.LastName,
                        Gender = !string.IsNullOrEmpty(documentModel.Gender) ? (documentModel.Gender.ToUpper().Equals("MALE") ? "Male" : (documentModel.Gender.ToUpper().Equals("FEMALE") ? "Female" : null)) : null,
                        ReservationNumber = SessionData.OperaReservation.ReservationNumber
                    }
                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                if (!responseModel.result)
                {
                    new LogHelper().Log("Failled to create accompanying profile with reason :- " + responseModel.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to fetch profile documents with reason :- " + responseModel.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }

                else if (responseModel.responseData == null)
                {
                    new LogHelper().Log("Failled to create accompanying profile with reason :- API response data is NULL" + responseModel.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to create accompanying profile with reason :- API response data is NULL" + responseModel.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
                else
                {
                    new LogHelper().Debug("Converting API json to object", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    try
                    {
                        Models.OWS.GuestProfile guest = JsonConvert.DeserializeObject<Models.OWS.GuestProfile>(responseModel.responseData.ToString());
                        uploadGuestDocumentModel.ProfileID = guest.PmsProfileID;
                    }
                    catch (Exception ex)
                    {
                        new LogHelper().Error(ex, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                        new LogHelper().Log("Failled to covert API response to object", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                        new LogHelper().Warn("Failled to create accompanying profile with reason :- " + ex.Message, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                        new LogHelper().Debug("Failled to create accompanying profile with reason :- " + ex.Message, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    }
                    new LogHelper().Log("Accompanying profile created successfully", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
            }

            else if (!string.IsNullOrEmpty(uploadGuestDocumentModel.ProfileID))
            {
                new LogHelper().Log("Updating guest profile in opera  - (Last name - +" + documentModel.LastName + ")", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                Models.OWS.OwsResponseModel owsResponse = await new CloudHelper().UpdateGuestProfile(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                {
                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                    LegNumber = "1",
                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                    UpdateProileRequest = new Models.OWS.UpdateProfile()
                    {
                        ProfileID = uploadGuestDocumentModel.ProfileID,
                        DOB = documentModel.BirthDate,

                        DocumentNumber = documentModel.DocumentNumber,
                        DocumentType = !string.IsNullOrWhiteSpace(documentModel?.DocumentType)
             ? GetDocumentByCode(documentModel.DocumentType): null,
                        Gender = !string.IsNullOrEmpty(documentModel.Gender) ? (documentModel.Gender.ToUpper().Equals("M") ? "Male" : (documentModel.Gender.ToUpper().Equals("F") ? "Female" : null)) : null,
                        IssueCountry = !string.IsNullOrWhiteSpace(documentModel?.IssueCountry) ?GetCountryByCode(documentModel.IssueCountry):null,
                        IssueDate = documentModel.IssueDate,
                        Nationality = !string.IsNullOrWhiteSpace(documentModel?.Nationality) ? GetCountryByCode(documentModel.Nationality):null

                    }
                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());

                if (!owsResponse.result)
                {
                    new LogHelper().Log("Failled to update profile with reason :- " + owsResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to update profile with reason :- " + owsResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
                else
                {
                    new LogHelper().Log("Updated profile successfully", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
            }

            if (!string.IsNullOrEmpty(uploadGuestDocumentModel.ProfileID))
            {
                new LogHelper().Log("Updating passport info in opera  - (Last name - +" + documentModel.LastName + ")", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                Models.OWS.OwsResponseModel owsResponse = await new CloudHelper().UpdateGuestProfile(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                {
                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                    LegNumber = "1",
                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                    UpdateProileRequest = new Models.OWS.UpdateProfile()
                    {
                        ProfileID = uploadGuestDocumentModel.ProfileID,
                        DOB = documentModel.BirthDate,

                        DocumentNumber = documentModel.DocumentNumber,
                        DocumentType = !string.IsNullOrWhiteSpace(documentModel?.DocumentType)
             ? GetDocumentByCode(documentModel.DocumentType) : null,
                        Gender = !string.IsNullOrEmpty(documentModel.Gender) ? (documentModel.Gender.ToUpper().Equals("M") ? "Male" : (documentModel.Gender.ToUpper().Equals("F") ? "Female" : null)) : null,
                        IssueCountry = !string.IsNullOrWhiteSpace(documentModel?.IssueCountry) ? GetCountryByCode(documentModel.IssueCountry) : null,
                        IssueDate = documentModel.IssueDate,
                        Nationality = !string.IsNullOrWhiteSpace(documentModel?.Nationality) ? GetCountryByCode(documentModel.Nationality) : null


                    }
                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());

                if (!owsResponse.result)
                {
                    new LogHelper().Log("Failled to update passport info with reason :- " + owsResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to update passport info with reason :- " + owsResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
                else
                {
                    new LogHelper().Log("Updated passport info successfully", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
            }






            #region Updating Profile guest
            //    new LogHelper().Log("Pushing profile guest", SessionData.OperaReservation.ReservationNameID, "UploadDocument", "Pre-Checkin");
            //    var localResponses = await new CloudHelper().InsertGuestProfile(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
            //    {
            //        RequestObject = new List<ProfileDetails>() {
            //                            new ProfileDetails
            //                            {
            //                                ReservationNameID = SessionData.OperaReservation.ReservationNameID,
            //                                LastName = documentModel.DocumentNumber,

            //                                Gender = documentModel.Gender,
            //                                FirstName = documentModel.FirstName,
            //                                Email = documentModel.Email,
            //                                CountryCode = null,
            //                                MiddleName = documentModel.MiddleName,
            //                                 BirthDate= documentModel.BirthDate,
            //                                Nationality = documentModel.Nationality,
            //                                City = documentModel.City,
            //                                Phone= documentModel.Phone,
            //                                PostalCode=documentModel.PostalCode,
            //                                AddressLine1 = documentModel.AddressLine1,
            //                                AddressLine2 = documentModel.AddressLine2,
            //                                StateCode=null,
            //                                ProfileID=uploadGuestDocumentModel.ProfileID
            //                            }
            //                        },
            //        SyncFromCloud = false

            //    }, "pre checked-in fetch", ConfigurationManager.AppSettings
            //["APIBaseUrl"].ToString());
            #endregion

            #region updateprofileby fetchingfrompms

            var reservationpms = await new CloudHelper().fetchReservationFromPMS(new Models.OWS.OwsRequestModel()
            {
                ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                LegNumber = "1",
                Language = ConfigurationManager.AppSettings["Language"].ToString(),
                Password = ConfigurationManager.AppSettings["Password"].ToString(),
                Username = ConfigurationManager.AppSettings["Username"].ToString(),
                SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                FetchBookingRequest = new Models.OWS.FetchBookingRequestModel()
                {
                    ReservationNumber = SessionData.OperaReservation.ReservationNumber

                }
            }, ConfigurationManager.AppSettings["APIBaseUrl"].ToString(), "precheckin", "uplod");

            if (reservationpms != null && reservationpms.Count > 0)
            {

                if (reservationpms.First().Adults != null && reservationpms.First().Adults.Value > 0)
                    SessionData.OperaReservation.GuestProfiles = reservationpms.First().GuestProfiles;
            }

            var localAPIResponse = await new CloudHelper().updateReservationDetailsInLocalDB(new APIRequestModel()
            {
                RequestObject = new List<Models.OWS.OperaReservation> { SessionData.OperaReservation },
                SyncFromCloud = false
                //changed to false by jeena on 1072023
            }, ConfigurationManager.AppSettings
                ["APIBaseUrl"], "upload");
            #endregion
            #region Updating Profile documents
            new LogHelper().Log("Pushing profile documents", SessionData.OperaReservation.ReservationNameID, "UploadDocument", "Pre-Checkin");
            var localResponse = await new CloudHelper().InsertDocuments(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
            {
                RequestObject = new List<ProfileDocuments>() {
                                    new ProfileDocuments
                                    {
                                        ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                                        DocumentNumber = documentModel.DocumentNumber,

                                        ExpiryDate = documentModel.ExpiryDate,
                                         DocumentTypeCode =documentModel.DocumentType,
                                        IssueCountry = documentModel.IssueCountry,
                                        ProfileID = uploadGuestDocumentModel.ProfileID.ToString(),
                                        DocumentImage1 = documentModel.DocumentImage1,
                                        DocumentImage2 = documentModel.DocumentImage2,
                                        DocumentImage3 = documentModel.DocumentImage3,
                                        FaceImage = documentModel.FaceImage
                                    }
                                },
                SyncFromCloud = false

            }, "pre checked-in fetch", ConfigurationManager.AppSettings
        ["APIBaseUrl"].ToString());
            if (!localResponse.result)
            {
                new LogHelper().Log("Failled to pushing profile documents with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                new LogHelper().Warn("Failled to pushing profile documents with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "UploadDocument", "Pre-Checkin");
            }
            else
                new LogHelper().Log("Profile documents updated in Local DB successfully", SessionData.OperaReservation.ReservationNameID, "UploadDocument", "Pre-Checkin");
            #endregion
            //reservationLogics.UpdateReservationByStage("Upload", documentModel);
            return Json(new { result = count > 0 });
        }

        [HttpPost]
        public async Task<ActionResult> SaveDeclaration(Answers answers, int ReservationID)
        {
            int count = 0;


            var Questions = reservationLogics.GetQuestions();


            Helpers.LogHelper.Instance.Log($"Updating Disclaimer", $"{ReservationID}", "SaveDeclaration", "Pre-Checkin");

            foreach (var question in Questions)
            {
                if (Request.Form["Answer[" + question.QuestionID + "]"] != null)
                {
                    var questionAns = Request.Form["Answer[" + question.QuestionID + "]"].ToString();
                    if (!string.IsNullOrEmpty(questionAns))
                    {
                        reservationLogics.InsertFeedback(ReservationID, question.QuestionID, questionAns);
                    }

                }
            }
            //push events to DB
            reservationLogics.InsertEvent(ReservationID, "Disclaimer");
            return Json(new { result = true });
        }

        public async Task<ActionResult> CompletePreCheckin(int ReservationID)
        {

            Helpers.LogHelper.Instance.Log($"PreCheckin Completed", $"{ReservationID}", "CompletePreCheckin", "Pre-Checkin");
            #region Pushing Reservation Track

            new LogHelper().Log("Pushing reservation track in local DB ", ReservationID.ToString(), "FetchPreCheckedInReservation", "pre checked-in fetch");
            #region Updating record status in Local DB
            new LogHelper().Log("Updating the reservation status in Local DB", SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
            var localResponse = await new CloudHelper().UpdateReservationStatus(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
            {
                RequestObject = new ReservationStatusRequestModel
                {
                    ReservationID = SessionData.OperaReservation.ReservationNameID,
                    Type = "PreCheckinComplete"
                }
            }, "Due-In push", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());

            if (!localResponse.result)
            {
                new LogHelper().Log("Updating the reservation status in Local DB with email send flag failled with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
            }
            else
                new LogHelper().Log("Updating the reservation status in Local DB ", SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
            #endregion

            localResponse = await new CloudHelper().PushReservationTrackLocally(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
            {
                RequestObject = new Models.ReservationTrackStatus()
                {
                    ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                    ProcessType = Models.ReservationProcessType.PreCheckedInFetched.ToString(),
                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                    ProcessStatus = "",
                    EmailSent = false
                }
            }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());

            if (localResponse.result)
            {
                new LogHelper().Log("Reservation track in local DB updated successfully ", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
            }
            else
            {
                new LogHelper().Log("Failled to update reservation track in local DB with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
            }
            #region Sending Email
            new LogHelper().Log("Sending confirmation email", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
            if (!string.IsNullOrEmpty(SessionData.OperaReservation.GuestProfiles[0].Email[0].email))
            {
                TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                Models.Emails.EmailResponse emailResponse = await new CloudHelper().SendEmail(SessionData.OperaReservation.ReservationNameID, new Models.Emails.EmailRequest()
                {
                    FromEmail = ConfigurationManager.AppSettings["PreArrivalConfirmationEmail"].ToString(),
                    ToEmail = SessionData.OperaReservation.GuestProfiles[0].Email[0].email,
                    GuestName = "" + (!string.IsNullOrEmpty(SessionData.OperaReservation.GuestProfiles[0].FirstName) ? textInfo.ToTitleCase(SessionData.OperaReservation.GuestProfiles[0].FirstName) + " " : "")
                                    + (!string.IsNullOrEmpty(SessionData.OperaReservation.GuestProfiles[0].MiddleName) ? textInfo.ToTitleCase(SessionData.OperaReservation.GuestProfiles[0].MiddleName) + " " : "")
                                    + (!string.IsNullOrEmpty(SessionData.OperaReservation.GuestProfiles[0].LastName) ? textInfo.ToTitleCase(SessionData.OperaReservation.GuestProfiles[0].LastName) : ""),

                    Subject = ConfigurationManager.AppSettings["PreArrivalConfirmationEmailSubject"].ToString(),
                    confirmationNumber = SessionData.OperaReservation.ReservationNumber,
                    displayFromEmail = ConfigurationManager.AppSettings["EmailDisplayName"].ToString(),
                    EmailType = Models.Emails.EmailType.CheckinConfirmation,
                    ArrivalDate = SessionData.OperaReservation.ArrivalDate.Value.ToString("dd-MMM-yyyy"),
                    DepartureDate = SessionData.OperaReservation.DepartureDate.Value.ToString("dd-MMM-yyy")

                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());

                if (!emailResponse.result)
                {
                    new LogHelper().Log("Failled to send confirmation email with reason :- " + emailResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                    new LogHelper().Warn("Failled to send confirmation email with reason :- " + emailResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                }
                else
                    new LogHelper().Log("Email send successfully", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
            }
            else
            {
                new LogHelper().Log("Failled to send confirmation email since email address not found from pre checked in list response", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                new LogHelper().Warn("Failled to send confirmation email since email address not found from pre checked in list response", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
            }
            #endregion

            #endregion

            var redirectURL = ConfigurationManager.AppSettings["PreCheckinCompleteRedirectURL"].ToString();
            return Redirect(redirectURL);
        }

        public ActionResult InsertEvent(string EventName, int reservationid)
        {
            reservationLogics.InsertEvent(reservationid, EventName);
            return Json(new { result = true });
        }

        //This is the function where adyen response will be send back
        public async Task<ActionResult> PaymentResponseFromGatewayold(string ConfirmationNo, string TransactionID)
        {
            Helpers.LogHelper.Instance.Log($"Payment response from PG after 3ds.", $"", "PaymentResponseFromGateway", "Pre-Checkin");

            PaymentLogics paymentLogics = new PaymentLogics();

            var paymentHistrory = paymentLogics.GetPaymentHistory(ConfirmationNo);

            //payment Detail call
            var details = new Dictionary<string, string>();
            details.Add("MD", Request.Params["MD"]);
            details.Add("PaRes", Request.Params["PaRes"]);

            MakePaymentDetailRequestModel paymentDetailsModel = new MakePaymentDetailRequestModel()
            {
                details = details,
                paymentData = paymentHistrory.Rows.Count > 0 ? paymentHistrory.Rows[0]["PData"].ToString() : "",// "Ab02b4c0!BQABAgCCVkrX4BAddf3ZRQieRyf7zQliVQ1hjGNu2cMjlepeRHzwglanbruU833xL6S8a+lcsZtRfQ1unFUFezebpaBCtAZ8N6exja8x/gWnig+cAXzhvfcOjFkDX8AZ6NFmuoBJOk/rp39Tnn8D6iRygQiVL6/uOUhLNCgpgfHLlRKLuczQyOAZV6xl19rtllRiPdrUEIv9jKrl/Io+VRnE0XJa3QcYagdQuBSw1xk7Koe2bHAvvjAs1Jk3YPw7lpOL6/nqBtXRAt/r/P28odxQzYmcwKpxqPQcKz+we0Xsn6971qBLWXW7of/npGb50ae8AboPPFoYj03YSOnkBidTVzQnRzbaZ/n/G2CHgf2mG0ZiOpf79cUGJuY8uyik5mdRLAxLpBoTh+jw9ffmRciipHR+PUMSP3UIgmdyuFcyOQ/T7ezV2g/HwIWKeXjJxUYFV7HnDAsP/dN0cUtkPn3e1ft1nQumjZtGu0kigahtmHIvJuFFGE0YYk9ac8uzDCkEzWebwacqxbKhwcyDllsYB/25HS1dxNi3xtGGSxMQhYG1kMyTw+LB3w/xvGLLnlryl7HUAL5NqCZLwKq9RhtUj0REdNjP4d8iNIvRmkUhzCrvtZBBYz73me1+AcTgc+Biwau2ok2n2aiPe7QP/Uom118Sqhws0ouhBMDgp+O6y4MC5RARnSR7VgAJdqyykBT8xXCLAEp7ImtleSI6IkFGMEFBQTEwM0NBNTM3RUFFRDg3QzI0REQ1MzkwOUI4MEE3OEE5MjNFMzgyM0Q2OERBQ0M5NEI5RkY4MzA1REMifWkYZm0bzeyTrwSZsSpXyNhsM5eZqnptl0Vs9fvoIp5/bI8Di+mNBtkaRbxKYANCio6uLe8RdMqsIL6fRf6K1KcvkUqvlHFuctOgX2JMLHyvlr8rdU/sZ6X1yx7IhqKTrAWIRmbCzrx+9VkX7DKKTmz2dg0h4QFNX8E6hhR8R3XShvNqkbyNNuhIH9xUnC7lPo9dkyxg6Gqf6L9ctPDQtvxW0p4Z/2riBCKljvpFpRw7SheCT+QxAK5GLUGGhbquz28ybr8gybN3OLm54JvAhI0+k1SQP7rzfWkThGZ34qjRPmR+o0a4nLZYBNImVTKOdHOyNhtgPycS0LqMf5QKpzOvbtU5A8LtNM6gVqGMo6BsywILANs/aHsKIan9aLtyanojUYrQBrVEH8Pb6/bHLhzG1sgAWudPI4zlmdTGSAlQagDC6Q/uWGsiPo5fk4S96FcxskuMkcixMdihioxwxuQpgJW1l8OzX8VA8T4lpU3Zejw3EOdjN59LTpCCl9sdRJOPt4dsKtrgWWcYxdoSsYKu+JrXgHTzo3f7fcV/xzkN8im9ACwJNGLOwOIxCZK26kUSrzKIHNjtQkPOue9ofZ3AaStDaCo3PANsgI5H2gmZZFCDOD+WVYOjHEZvrphHRCkoq+CUyYRl9ysDj1c1vLRg+lNHUyHW8z8XdCLI2hTZN3TQVW+T0PhGVBSVn8cHjWJuFaPaPwfwScOUBDrpDMRzQXaS/c3ZbvLUkhpSuBSTFtVrjO06vNtVIBWXz8hl79Jn6lEWqKCrEtoLehHG+6Xvmzz517lvRzaC6MbOrYdAi3YlyXWwNxJqEfA97idShaQNFk2RIObG5KttVbr5ZBVchF4gHduCxrZEBj90vlSBObpos/WMu0ox3fzcCrRyc2k0AbAJvQ8ygt1O054uYsdZWRdswyXx3FK+mdlXLyTQH9LjcKCXEk7RBChjBEPfsSdry3C+NvfQ/MIWRvXI6+ojBiPVG287NL7OahM5xrY+VfQTRMmmePt+LZKJxXc4+HlTySoYBXXteVQ6tBdWmUmk7hycjjL8tHQINBXB5vpR5M2ZAzfdhywom3065j/X2OwhIi3Qlvf3m2CMbPgeA3AdcGcdslAfmhKG62rwRov0d52XTPbl9XFk2GPjR6OF77oV4J5Fi1euat7ZMF4VDYgpx4Ekj/897aUJVq1UmOHAlEVS7npCeWNu8SXOFt86tXiA5DSkd+9zYqoo7KmThaIny6w40/pQlW5IV3Q2uQdzyCAprwVrfij1hTGIcmP7AZQohd6Ha4Im6tmEvDZC7lPr/IOCDbQ9cNtOcNRTC+hSHXpZ0hbimDGXRdZOFeuW7NFmmn2A1aQu4mU5H++doxAZ7kjLERb0BjtUe8TUeqO2SOySoLm4wazwd6/MmR64KDCYxhE5192vps88raZrdgmOy7Vq+MqzMZkzJ6Dl8d3ITlCoSh3/LWGmMUglMtJJvATwoD+rQ5rfU13RW4r6f2w9rBovkFV9UiAQY+Hi228W5uaiBQeQzVpqNJ6hfy1rqcHJuHHo03IRY3nz0czIxQVftyi0fivsKI7jVXDLKXRKWbBATH61iDhvw54mvj8Lk+TSXBBh0dbq/2KkdVPk/1eLSQgeMXzVjXG7KA=="
            };

            using (var httpClient = new HttpClient())
            {

                string BaseURL = ConfigurationManager.AppSettings["AdaptorAPIPaymentBaseURL"].ToString();
                string APIKey = ConfigurationManager.AppSettings["APIKey"].ToString();
                string MerchantAccount = ConfigurationManager.AppSettings["MerchantAccount"].ToString();
                string CostEstimator_MCC = ConfigurationManager.AppSettings["CostEstimator_MCC"].ToString();

                MakePaymentDetailRequestModelRoot makePaymentDetailRequestModelRoot = new MakePaymentDetailRequestModelRoot()
                {
                    apiKey = APIKey,
                    MerchantAccount = MerchantAccount,
                    RequestObject = paymentDetailsModel
                };

                httpClient.BaseAddress = new Uri(BaseURL);

                string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(makePaymentDetailRequestModelRoot);

                httpClient.DefaultRequestHeaders.Clear();
                //httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //httpClient.DefaultRequestHeaders.Add("x-api-key", "AQE1hmfuXNWTK0Qc+iSDk2UuvsaOW4JDCIBZa3xF0n2mjVZdiutiFFJB8m+HZPXmoKVywMgI/xQQwV1bDb7kfNy1WIxIIkxgBw==-rODJO2F2/g0t6SNBtX135za8qsAPMapU1bIGmWrLDP8=-:=GN%5%nV5Tpj*=W");

                HttpContent requestContent = new StringContent(jsonString, Encoding.UTF8, "application/json");

                Helpers.LogHelper.Instance.Log($"Getting Payment Details from PG", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                HttpResponseMessage response = await httpClient.PostAsync($"GetPaymentDetails", requestContent);

                if (response.IsSuccessStatusCode)
                {

                    string Test = await response.Content.ReadAsStringAsync();

                    Helpers.LogHelper.Instance.Debug($"Got Payment Response from PG : {Test}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                    var resposneObj = Newtonsoft.Json.JsonConvert.DeserializeObject<Models.AdaptorAPIModels.MakePaymentResponseModel>(Test);

                    if (resposneObj != null && resposneObj.Result)
                    {
                        Helpers.LogHelper.Instance.Log($"Updating payment details to DB", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                        await reservationLogics.InsertPaymentData(resposneObj.ResponseObject, ConfirmationNo, paymentHistrory.Rows[0]["ReservationNameID"].ToString(), paymentHistrory.Rows[0]["TransactionID"].ToString(), paymentHistrory.Rows[0]["TransactionType"].ToString());

                        paymentLogics.SaveTransactionHistory(new InsertPaymentHistoryUspModel()
                        {
                            ReservationNameID = resposneObj.ResponseObject.MerchantRefernce.Split('-')[1],
                            PData = paymentHistrory.Rows[0]["PData"].ToString(),
                            PaRes = Request.Params["PaRes"],
                            MDData = Request.Params["MD"],
                            PSPReference = resposneObj.ResponseObject.PspReference,
                            RefusalReason = resposneObj.ResponseObject.RefusalReason,
                            ReservationNumber = resposneObj.ResponseObject.MerchantRefernce.Split('-')[0],
                            ResultCode = resposneObj.ResponseObject.ResultCode,
                            TransactionID = TransactionID,
                            TransactionType = paymentHistrory.Rows[0]["TransactionType"].ToString()
                        });

                        if (resposneObj.ResponseObject.ResultCode == "Authorised")
                        {
                            Helpers.LogHelper.Instance.Log($"Payment {resposneObj.ResponseObject.ResultCode}, Updating payment status to BD", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                            #region  Precheckin Completed
                            var reservationsDt = reservationLogics.GetReservationDetailsDT(ConfirmationNo);
                            var reservations = Helpers.DataTableHelper.DataTableToList<DataAccess.usp_GetReservationDetails_Result>(reservationsDt);

                            var localResponse = await new CloudHelper().PushReservationTrackLocally(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                            {
                                RequestObject = new Models.ReservationTrackStatus()
                                {
                                    ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                                    ProcessType = Models.ReservationProcessType.PreCheckedInFetched.ToString(),
                                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                    ProcessStatus = "",
                                    EmailSent = false
                                }
                            }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                            if (localResponse.result)
                            {
                                new LogHelper().Log("Reservation track in local DB updated successfully ", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }
                            else
                            {
                                new LogHelper().Log("Failled to update reservation track in local DB with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }


                            #endregion



                            //Make payment sucess flag.
                            await paymentLogics.UpdateReservationPaymentStatus(ConfirmationNo);

                            TempData["IsredirectedfromPaymentPage"] = true;
                            TempData["IsPaymentSuccess"] = true;
                            TempData["PaymentFailureMessage"] = "";


                        }
                        else
                        {
                            Helpers.LogHelper.Instance.Log($"Payment {resposneObj.ResponseObject.ResultCode}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                            //log error
                            TempData["IsredirectedfromPaymentPage"] = true;
                            TempData["IsPaymentSuccess"] = false;
                            TempData["PaymentFailureMessage"] = resposneObj.ResponseObject.RefusalReason;

                        }
                        //return Json(new { result = true, content = Test });
                    }
                    else
                    {
                        string FailureMessage = string.Empty;
                        if (resposneObj != null)
                        {
                            FailureMessage = resposneObj.ResponseMessage;
                        }

                        Helpers.LogHelper.Instance.Log($"Payment failed {FailureMessage}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                        TempData["IsredirectedfromPaymentPage"] = true;
                        TempData["IsPaymentSuccess"] = false;
                        TempData["PaymentFailureMessage"] = "Unable to complete the payment, Please try again";
                    }
                }
                else
                {
                    Helpers.LogHelper.Instance.Log($"Payment failed {response.IsSuccessStatusCode}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                    TempData["IsredirectedfromPaymentPage"] = true;
                    TempData["IsPaymentSuccess"] = false;
                    TempData["PaymentFailureMessage"] = "Unable to complete the payment, Please try again";
                }
            }

            //redirect back to registraton document processing tab
            string encConfirmationNo = Helpers.EncryptionHelper.EncryptString(ConfirmationNo);


            return RedirectToAction("IndexPayment", new { id = ConfirmationNo });

        }
        public async Task<ActionResult> PaymentResponseFromGateway(string ConfirmationNo, string TransactionID)
        {
            List<Models.PaymentHistory> paymentHistories = new List<Models.PaymentHistory>();
            List<Models.PaymentHistory> paymentHistory = new List<Models.PaymentHistory>();
            List<Models.PaymentAdditionalInfo> paymentAdditionalInfos = new List<Models.PaymentAdditionalInfo>();
            List<Models.PaymentHeader> paymentHeaders = new List<Models.PaymentHeader>();
            List<PaymentTypeMasterModel> payments = new List<PaymentTypeMasterModel>();
            Helpers.LogHelper.Instance.Log($"Payment response from PG after 3ds.", $"", "PaymentResponseFromGateway", "Pre-Checkin");

            PaymentLogics paymentLogics = new PaymentLogics();

            var paymentHistrory = await new CloudHelper().FetchPaymentHistory(ConfirmationNo, new APIRequestModel() { RequestObject = ConfirmationNo }, "", ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString());
            if (paymentHistrory != null)
            {
                paymentHistory = (List<PaymentHistory>)paymentHistrory.responseData;
            }
            payments = await new CloudHelper().fetchPaymentTypeMaster(ConfigurationManager.AppSettings
                   ["APIBaseUrl"].ToString(), "Pre-Checkin");
            //payment Detail call
            var details = new Dictionary<string, string>();
            details.Add("MD", Request.Params["MD"]);
            details.Add("PaRes", Request.Params["PaRes"]);

            MakePaymentDetailRequestModel paymentDetailsModel = new MakePaymentDetailRequestModel()
            {
                details = details,
                paymentData = paymentHistory != null ? paymentHistory.FirstOrDefault().PData : "",
            };

            using (var httpClient = new HttpClient())
            {

                string BaseURL = ConfigurationManager.AppSettings["AdaptorAPIPaymentBaseURL"].ToString();
                string APIKey = ConfigurationManager.AppSettings["APIKey"].ToString();
                string MerchantAccount = ConfigurationManager.AppSettings["MerchantAccount"].ToString();
                string CostEstimator_MCC = ConfigurationManager.AppSettings["CostEstimator_MCC"].ToString();

                MakePaymentDetailRequestModelRoot makePaymentDetailRequestModelRoot = new MakePaymentDetailRequestModelRoot()
                {
                    apiKey = APIKey,
                    MerchantAccount = MerchantAccount,
                    RequestObject = paymentDetailsModel
                };

                httpClient.BaseAddress = new Uri(BaseURL);

                string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(makePaymentDetailRequestModelRoot);

                httpClient.DefaultRequestHeaders.Clear();

                var accessToken = AuthenticationHelper.GetAPIAccessToken();
                if (!string.IsNullOrEmpty(accessToken))
                {
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                }
                HttpContent requestContent = new StringContent(jsonString, Encoding.UTF8, "application/json");

                Helpers.LogHelper.Instance.Log($"Getting Payment Details from PG", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                HttpResponseMessage response = await httpClient.PostAsync($"GetPaymentDetails", requestContent);

                if (response.IsSuccessStatusCode)
                {

                    string Test = await response.Content.ReadAsStringAsync();

                    Helpers.LogHelper.Instance.Debug($"Got Payment Response from PG : {Test}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                    var resposneObj = Newtonsoft.Json.JsonConvert.DeserializeObject<Models.AdaptorAPIModels.MakePaymentResponseModel>(Test);

                    if (resposneObj != null && resposneObj.Result)
                    {
                        Helpers.LogHelper.Instance.Log($"Updating payment details to DB", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                        #region create pamentdata
                        try
                        {
                            paymentHeaders.Add(new PaymentHeader
                            {
                                MaskedCardNumber = resposneObj.ResponseObject.MaskCardNumber,
                                FundingSource = resposneObj.ResponseObject.FundingSource,
                                Amount = resposneObj.ResponseObject.Amount.Value.ToString("0.00"),
                                TransactionID = paymentHistory != null ? paymentHistory.FirstOrDefault().TransactionID : "",
                                ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                                ExpiryDate = resposneObj.ResponseObject.CardExpiryDate,
                                AuthorisationCode = resposneObj.ResponseObject.AuthCode,
                                Currency = resposneObj.ResponseObject.Currency,
                                RecurringIdentifier = resposneObj.ResponseObject.PaymentToken,
                                pspReferenceNumber = resposneObj.ResponseObject.PspReference,
                                ParentPspRefereceNumber = string.IsNullOrEmpty(resposneObj.ResponseObject.ParentPSPReferece) ? resposneObj.ResponseObject.PspReference : resposneObj.ResponseObject.ParentPSPReferece,
                                TransactionType = paymentHistory != null ? paymentHistory.FirstOrDefault().TransactionID : "TransactionType",
                                ResultCode = resposneObj.ResponseObject.ResultCode,
                                ResponseMessage = resposneObj.ResponseObject.RefusalReason,
                                CardType = resposneObj.ResponseObject.CardType,
                                OperaPaymentTypeCode = resposneObj.ResponseObject.CardType!=null?payments.Where(x => x.VendorPaymentTypeCode.ToUpper() == resposneObj.ResponseObject.CardType.ToUpper()).FirstOrDefault()?.OperaPaymentTypeCode : null
                            });



                            DataTable dataTable = new DataTable();
                            dataTable.Columns.Add("KeyHeader", typeof(string));
                            dataTable.Columns.Add("KeyValue", typeof(string));


                            if (resposneObj.ResponseObject.additionalInfos != null)
                            {
                                foreach (var item in resposneObj.ResponseObject.additionalInfos)
                                {
                                    paymentAdditionalInfos.Add(new PaymentAdditionalInfo
                                    {
                                        KeyHeader = item.key,
                                        KeyValue = item.value
                                    });

                                }
                            }



                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        #endregion
                        #region create paymenthistory
                        paymentHistories.Add(new PaymentHistory
                        {
                            MDData = Request.Params["MD"],
                            PaRes = Request.Params["PaRes"],
                            PData = paymentHistory != null ? paymentHistory.FirstOrDefault().PData : "",
                            PSPReference = resposneObj.ResponseObject.PspReference,
                            RefusalReason = resposneObj.ResponseObject.RefusalReason,
                            ReservationNameID = resposneObj.ResponseObject.MerchantRefernce.Split('-')[1],
                            ReservationNumber = resposneObj.ResponseObject.MerchantRefernce.Split('-')[0],
                            ResultCode = resposneObj.ResponseObject.ResultCode,
                            TransactionID = TransactionID,
                            TransactionType = paymentHistory != null ? paymentHistory.FirstOrDefault().TransactionType : ""

                        });
                        #endregion
                        #region InsertPayment

                        #endregion
                        if (resposneObj.ResponseObject.ResultCode == "Authorised")
                        {
                            #region update payment to opera
                            #region Update payment in opera
                            var paymentDetails = new Models.UpdatePaymentDetails()
                            {
                                paymentHeaders = paymentHeaders,
                                paymentAdditionalInfos = paymentAdditionalInfos,
                                paymentHistories = paymentHistories
                            };
                            if (paymentDetails != null)
                            {


                                int x = 0;
                                new LogHelper().Log("Iterating the payment headers", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                foreach (Models.PaymentHeader paymentHeader in paymentDetails.paymentHeaders)
                                {
                                    if (paymentHeader.IsActive == null)
                                    {
                                        new LogHelper().Log("Processing the payment header with psprefernce - " + paymentHeader.pspReferenceNumber + " where IsActive falg is NULL", "", "FetchPreCheckedInReservation", "pre checked-in fetch");

                                        #region Update Opera
                                        if (paymentDetails.paymentHeaders[x].TransactionType.Equals(Models.TransactionType.PreAuth.ToString()))
                                        {
                                            new LogHelper().Log("Processing the payment header with psprefernce - " + paymentHeader.pspReferenceNumber + " as a pre-auth transaction", "", "FetchPreCheckedInReservation", "pre checked-in fetch");

                                            paymentDetails.paymentHeaders[x].IsActive = true;

                                            #region Updating Card details in opera Reservation
                                            new LogHelper().Log("Updating credit card details in the reservation", "", "FetchPreCheckedInReservation", "pre checked-in fetch");

                                            Models.OWS.OwsResponseModel owsResponse = await new CloudHelper().UpdateCardDetailsInReservationAsyn("", new Models.OWS.OwsRequestModel()
                                            {
                                                ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                                DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                                DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                                HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                                KioskID = ConfigurationManager.AppSettings
                ["KioskID"].ToString(),
                                                LegNumber = "1",
                                                Language = ConfigurationManager.AppSettings
                ["Language"].ToString(),
                                                Password = ConfigurationManager.AppSettings
                ["Password"].ToString(),
                                                Username = ConfigurationManager.AppSettings
                ["Username"].ToString(),
                                                SystemType = ConfigurationManager.AppSettings
                ["SystemType"].ToString(),
                                                modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                                {
                                                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                                    isUDFFieldSpecified = false,
                                                    updateCreditCardDetails = true,
                                                    GarunteeTypeCode = ConfigurationManager.AppSettings
                ["GarunteeTypeCode"].ToString(),// "CC",
                                                    PaymentMethod = new Models.OWS.PaymentMethod()
                                                    {
                                                        ExpiryDate = !string.IsNullOrEmpty(paymentDetails.paymentHeaders[x].ExpiryDate) ? "01/" + paymentDetails.paymentHeaders[x].ExpiryDate : null,
                                                        MaskedCardNumber = paymentDetails.paymentHeaders[x].MaskedCardNumber,
                                                        PaymentType = paymentDetails.paymentHeaders[x].OperaPaymentTypeCode

                                                    }
                                                }
                                            }, "pre checked-in fetch", ConfigurationManager.AppSettings
                ["APIBaseUrl"].ToString());
                                            if (!owsResponse.result)
                                            {
                                                new LogHelper().Log("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                new LogHelper().Warn("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            else
                                            {
                                                new LogHelper().Log("Updating credit card details in the reservation succeeded", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                new LogHelper().Warn("Updating credit card details in the reservation succeeded", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            #endregion

                                            #region Updating UDF fields in Opera reservation
                                            try
                                            {
                                                new LogHelper().Log("Updating pre auth code and amount in UDF fileds", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                owsResponse = await new CloudHelper().ModifyBooking(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                                {
                                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                                    KioskID = ConfigurationManager.AppSettings
                ["KioskID"].ToString(),
                                                    LegNumber = "1",
                                                    Language = ConfigurationManager.AppSettings
                ["Language"].ToString(),
                                                    Password = ConfigurationManager.AppSettings
                ["Password"].ToString(),
                                                    Username = ConfigurationManager.AppSettings
                ["Username"].ToString(),
                                                    SystemType = ConfigurationManager.AppSettings
                ["SystemType"].ToString(),
                                                    modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                                    {
                                                        isUDFFieldSpecified = true,
                                                        ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                                        uDFFields = new List<Models.OWS.UDFField>()
                                                                                {
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.pspReferenceNumber
                                                                                    },
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthAmntUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.Amount
                                                                                    }
                                                                                }
                                                    }
                                                }, "pre checked-in fetch", ConfigurationManager.AppSettings
                ["APIBaseUrl"].ToString()
);
                                                if (!owsResponse.result)
                                                {
                                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                    new LogHelper().Warn("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                }
                                                else
                                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds succeeded ", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            catch (Exception ex)
                                            {
                                                new LogHelper().Error(ex, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            #endregion

                                        }
                                        else if (paymentDetails.paymentHeaders[x].TransactionType.Equals(Models.TransactionType.Sale.ToString()))
                                        {
                                            paymentDetails.paymentHeaders[x].IsActive = false;

                                            #region Updating Card details in opera Reservation
                                            new LogHelper().Log("Updating credit card details in the reservation", "", "FetchPreCheckedInReservation", "pre checked-in fetch");

                                            Models.OWS.OwsResponseModel owsResponse = await new CloudHelper().UpdateCardDetailsInReservationAsyn(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                            {
                                                ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                                DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                                DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                                HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                                KioskID = ConfigurationManager.AppSettings
                ["KioskID"].ToString(),
                                                LegNumber = "1",
                                                Language = ConfigurationManager.AppSettings
                ["Language"].ToString(),
                                                Password = ConfigurationManager.AppSettings
                ["Password"].ToString(),
                                                Username = ConfigurationManager.AppSettings
                ["Username"].ToString(),
                                                SystemType = ConfigurationManager.AppSettings
                ["SystemType"].ToString(),
                                                modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                                {
                                                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                                    isUDFFieldSpecified = false,
                                                    updateCreditCardDetails = true,
                                                    GarunteeTypeCode = ConfigurationManager.AppSettings
                ["GarunteeTypeCode"].ToString(),//"CC",
                                                    PaymentMethod = new Models.OWS.PaymentMethod()
                                                    {
                                                        ExpiryDate = !string.IsNullOrEmpty(paymentDetails.paymentHeaders[x].ExpiryDate) ? "01/" + paymentDetails.paymentHeaders[x].ExpiryDate : null,
                                                        MaskedCardNumber = paymentDetails.paymentHeaders[x].MaskedCardNumber,
                                                        PaymentType = paymentDetails.paymentHeaders[x].OperaPaymentTypeCode

                                                    }
                                                }
                                            }, "pre checked-in fetch", ConfigurationManager.AppSettings
                ["APIBaseUrl"].ToString());
                                            if (!owsResponse.result)
                                            {
                                                new LogHelper().Log("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                new LogHelper().Warn("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            else
                                            {
                                                new LogHelper().Log("Updating credit card details in the reservation succeeded", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                new LogHelper().Warn("Updating credit card details in the reservation succeeded", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            #endregion

                                            #region Updating UDF fields in Opera reservation
                                            try
                                            {
                                                new LogHelper().Log("Updating pre auth code and amount in UDF fileds", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                owsResponse = await new CloudHelper().ModifyBooking(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                                {
                                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                                    KioskID = ConfigurationManager.AppSettings
                ["KioskID"].ToString(),
                                                    LegNumber = "1",
                                                    Language = ConfigurationManager.AppSettings
                ["Language"].ToString(),
                                                    Password = ConfigurationManager.AppSettings
                ["Password"].ToString(),
                                                    Username = ConfigurationManager.AppSettings
                ["Username"].ToString(),
                                                    SystemType = ConfigurationManager.AppSettings
                ["SystemType"].ToString(),
                                                    modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                                    {
                                                        isUDFFieldSpecified = true,
                                                        ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                                        uDFFields = new List<Models.OWS.UDFField>()
                                                                                {
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.pspReferenceNumber
                                                                                    },
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthAmntUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.Amount
                                                                                    }
                                                                                }
                                                    }
                                                }, "pre checked-in fetch", ConfigurationManager.AppSettings
                ["APIBaseUrl"].ToString());
                                                if (!owsResponse.result)
                                                {
                                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                    new LogHelper().Warn("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                }
                                                else
                                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds succeeded ", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            catch (Exception ex)
                                            {
                                                new LogHelper().Error(ex, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            #endregion

                                            #region Posting payment in opera reservation
                                            try
                                            {
                                                new LogHelper().Log("Posting payment in the reservation", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                owsResponse = await new CloudHelper().MakePayment(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                                {
                                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                                    KioskID = ConfigurationManager.AppSettings
                ["KioskID"].ToString(),
                                                    LegNumber = "1",
                                                    Language = ConfigurationManager.AppSettings
                ["Language"].ToString(),
                                                    Password = ConfigurationManager.AppSettings
                ["Password"].ToString(),
                                                    Username = ConfigurationManager.AppSettings
                ["Username"].ToString(),
                                                    SystemType = ConfigurationManager.AppSettings
                ["SystemType"].ToString(),
                                                    MakePaymentRequest = new Models.OWS.MakePaymentRequest()
                                                    {
                                                        Amount = Convert.ToDecimal(paymentHeader.Amount),
                                                        PaymentInfo = "Payment from web checkin",
                                                        StationID = "MCI",
                                                        WindowNumber = 1,
                                                        ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                                                        MaskedCardNumber = paymentHeader.MaskedCardNumber.ToLower(),
                                                        PaymentRefernce = "Payment from web checkin - Sale",
                                                        PaymentTypeCode = paymentHeader.OperaPaymentTypeCode,
                                                        ApprovalCode = paymentHeader.pspReferenceNumber
                                                    }
                                                }, "pre checked-in fetch", ConfigurationManager.AppSettings
                ["APIBaseUrl"].ToString());
                                                if (!owsResponse.result)
                                                {
                                                    new LogHelper().Log("Posting payment failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                    new LogHelper().Warn("Posting payment failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                                }
                                                else
                                                    new LogHelper().Log("Posting payment in opera reservation succeeded ", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            catch (Exception ex)
                                            {
                                                new LogHelper().Error(ex, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            }
                                            #endregion
                                        }
                                        else if (paymentDetails.paymentHeaders[x].TransactionType.Equals(Models.TransactionType.Capture.ToString()))
                                        {
                                            new LogHelper().Log("Wrong payment header retuned and Is active NULL (Capture)", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                            paymentDetails.paymentHeaders[x].IsActive = false;
                                        }

                                        #endregion
                                    }
                                    x++;
                                }
                                new LogHelper().Log("payment details updated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");

                            }
                            ////jkj
                            #endregion

                            #region Pushing Payment details in LOcal Db

                            new LogHelper().Log("Updating payment details in local DB", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                            var localResponse = await new CloudHelper().PushPaymentDetails(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                            {
                                RequestObject = paymentDetails
                            }, "pre checked-in fetch", ConfigurationManager.AppSettings
                      ["APIBaseUrl"].ToString());
                            if (!localResponse.result)
                            {
                                new LogHelper().Log("Failled to update payment details in Local DB with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                new LogHelper().Warn("Failled to update payment details in local DB with reason :- " + localResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }
                            else
                                new LogHelper().Log("Payment details updated successfully", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                            #endregion
                            #endregion

                            Helpers.LogHelper.Instance.Log($"Payment {resposneObj.ResponseObject.ResultCode}, Updating payment status to BD", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                            #region  Precheckin Completed
                            var reservationsDt = reservationLogics.GetReservationDetailsDT(ConfirmationNo);
                            var reservations = Helpers.DataTableHelper.DataTableToList<DataAccess.usp_GetReservationDetails_Result>(reservationsDt);
                            #region Updating record status in Local DB
                            new LogHelper().Log("Updating the reservation status in Local DB", SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
                            localResponse = await new CloudHelper().UpdateReservationStatus(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                            {
                                RequestObject = new ReservationStatusRequestModel
                                {
                                    ReservationID = SessionData.OperaReservation.ReservationNameID,
                                    Type = "EcomInComplete"
                                }
                            }, "Due-In push", ConfigurationManager.AppSettings
                  ["APIBaseUrl"].ToString());
                            if (!localResponse.result)
                            {
                                new LogHelper().Log("Updating the reservation status in Local DB with email send flag failled with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
                            }
                            else
                                new LogHelper().Log("Updating the reservation status in Local DB ", SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
                            #endregion
                            localResponse = await new CloudHelper().PushReservationTrackLocally(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                            {
                                RequestObject = new Models.ReservationTrackStatus()
                                {
                                    ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                                    ProcessType = Models.ReservationProcessType.PreCheckedInFetched.ToString(),
                                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                    ProcessStatus = "",
                                    EmailSent = false
                                }
                            }, "pre checked-in fetch", ConfigurationManager.AppSettings
                   ["APIBaseUrl"].ToString());
                            if (localResponse.result)
                            {
                                new LogHelper().Log("Reservation track in local DB updated successfully ", SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }
                            else
                            {
                                new LogHelper().Log("Failled to update reservation track in local DB with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }


                            #endregion



                            //Make payment sucess flag.
                            // await paymentLogics.UpdateReservationPaymentStatus(ConfirmationNo);

                            TempData["IsredirectedfromPaymentPage"] = true;
                            TempData["IsPaymentSuccess"] = true;
                            TempData["PaymentFailureMessage"] = "";


                        }
                        else
                        {
                            Helpers.LogHelper.Instance.Log($"Payment {resposneObj.ResponseObject.ResultCode}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                            //log error
                            TempData["IsredirectedfromPaymentPage"] = true;
                            TempData["IsPaymentSuccess"] = false;
                            TempData["PaymentFailureMessage"] = resposneObj.ResponseObject.RefusalReason;

                        }
                        //return Json(new { result = true, content = Test });
                    }
                    else
                    {
                        string FailureMessage = string.Empty;
                        if (resposneObj != null)
                        {
                            FailureMessage = resposneObj.ResponseMessage;
                        }

                        Helpers.LogHelper.Instance.Log($"Payment failed {FailureMessage}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                        TempData["IsredirectedfromPaymentPage"] = true;
                        TempData["IsPaymentSuccess"] = false;
                        TempData["PaymentFailureMessage"] = "Unable to complete the payment, Please try again";
                    }
                }
                else
                {
                    Helpers.LogHelper.Instance.Log($"Payment failed {response.IsSuccessStatusCode}", $"", "PaymentResponseFromGateway", "Pre-Checkin");

                    TempData["IsredirectedfromPaymentPage"] = true;
                    TempData["IsPaymentSuccess"] = false;
                    TempData["PaymentFailureMessage"] = "Unable to complete the payment, Please try again";
                }
            }

            //redirect back to registraton document processing tab
            string encConfirmationNo = Helpers.EncryptionHelper.EncryptString(ConfirmationNo);


            return RedirectToAction("IndexPayment", new { id = ConfirmationNo });

        }
        public async Task<ActionResult> InsertPaymentResponseHeader(PaymentResponse paymentResponse, string ConfirmationNo, string ReservationNameID, string TransactionID, string TransactionType)
        {

            string ActionName = "InsertPaymentResponseHeader", ActionGroup = "Pre-Checkin";
            PaymentLogics paymentLogics = new PaymentLogics();
            List<Models.PaymentHistory> paymentHistory = new List<Models.PaymentHistory>();
            List<Models.PaymentAdditionalInfo> paymentAdditionalInfos = new List<Models.PaymentAdditionalInfo>();
            List<Models.PaymentHeader> paymentHeaders = new List<Models.PaymentHeader>();
            List<PaymentTypeMasterModel> payments = new List<PaymentTypeMasterModel>();
            Helpers.LogHelper.Instance.Log($"Updating payment details non 3ds", $"", ActionName, ActionGroup);
            if (paymentResponse != null)
            {
                Helpers.LogHelper.Instance.Log($"Updating payment response {Newtonsoft.Json.JsonConvert.SerializeObject(paymentResponse)}", $"", ActionName, ActionGroup);
            }
            payments = await new CloudHelper().fetchPaymentTypeMaster(ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString(), ActionGroup);
            bool response = false;
            #region create pamentdata
            try
            {
                paymentHeaders.Add(new PaymentHeader
                {
                    MaskedCardNumber = paymentResponse.MaskCardNumber,
                    FundingSource = paymentResponse.FundingSource,
                    Amount = paymentResponse.Amount.Value.ToString("0.00"),
                    TransactionID = TransactionID,
                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                    ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                    ExpiryDate = paymentResponse.CardExpiryDate,
                    AuthorisationCode = paymentResponse.AuthCode,
                    Currency = paymentResponse.Currency,
                    RecurringIdentifier = paymentResponse.PaymentToken,
                    pspReferenceNumber = paymentResponse.PspReference,
                    ParentPspRefereceNumber = string.IsNullOrEmpty(paymentResponse.ParentPSPReferece) ? paymentResponse.PspReference : paymentResponse.ParentPSPReferece,
                    TransactionType = TransactionType,
                    ResultCode = paymentResponse.ResultCode,
                    ResponseMessage = paymentResponse.RefusalReason ?? "",
                    CardType = paymentResponse.CardType,
                    OperaPaymentTypeCode = payments.Where(x => x.VendorPaymentTypeCode.ToUpper() == paymentResponse.CardType.ToUpper()).FirstOrDefault().OperaPaymentTypeCode

                });



                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("KeyHeader", typeof(string));
                dataTable.Columns.Add("KeyValue", typeof(string));


                if (paymentResponse.additionalInfos != null)
                {
                    foreach (var item in paymentResponse.additionalInfos)
                    {
                        paymentAdditionalInfos.Add(new PaymentAdditionalInfo
                        {
                            KeyHeader = item.key,
                            KeyValue = item.value
                        });

                    }
                }

                paymentHistory.Add(new PaymentHistory
                {
                    TransactionID = TransactionID,
                    ReservationNameID = paymentResponse.MerchantRefernce.Split('-')[1],
                    ReservationNumber = paymentResponse.MerchantRefernce.Split('-')[0],

                    // PData = paymentDetailResponseModel.r,
                    PaRes = Request.Params["PaRes"],
                    MDData = Request.Params["MD"],
                    PSPReference = paymentResponse.PspReference,
                    RefusalReason = paymentResponse.RefusalReason,
                    ResultCode = paymentResponse.ResultCode,
                    TransactionType = TransactionType
                });

            }
            catch (Exception ex)
            {
                throw ex;
            }
            #endregion
            #region update payment to opera
            #region Update payment in opera
            var paymentDetails = new Models.UpdatePaymentDetails()
            {
                paymentHeaders = paymentHeaders,
                paymentAdditionalInfos = paymentAdditionalInfos,
                paymentHistories = paymentHistory
            };
            if (paymentDetails != null)
            {


                int x = 0;
                new LogHelper().Log("Iterating the payment headers", "", ActionName, ActionGroup);
                foreach (Models.PaymentHeader paymentHeader in paymentDetails.paymentHeaders)
                {
                    if (paymentHeader.IsActive == null)
                    {
                        new LogHelper().Log("Processing the payment header with psprefernce - " + paymentHeader.pspReferenceNumber + " where IsActive falg is NULL", "", ActionName, ActionGroup);

                        #region Update Opera
                        if (paymentDetails.paymentHeaders[x].TransactionType.Equals(Models.TransactionType.PreAuth.ToString()))
                        {
                            new LogHelper().Log("Processing the payment header with psprefernce - " + paymentHeader.pspReferenceNumber + " as a pre-auth transaction", "", ActionName, ActionGroup);

                            paymentDetails.paymentHeaders[x].IsActive = true;

                            #region Updating Card details in opera Reservation
                            new LogHelper().Log("Updating credit card details in the reservation", "", ActionName, ActionGroup);
                            Models.OWS.OwsResponseModel owsResponse = await new CloudHelper().UpdateCardDetailsInReservationAsyn("", new Models.OWS.OwsRequestModel()
                            {
                                ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                                LegNumber = "1",
                                Language = ConfigurationManager.AppSettings["Language"].ToString(),
                                Password = ConfigurationManager.AppSettings["Password"].ToString(),
                                Username = ConfigurationManager.AppSettings["Username"].ToString(),
                                SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                                modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                {
                                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                    isUDFFieldSpecified = false,
                                    updateCreditCardDetails = true,
                                    GarunteeTypeCode = ConfigurationManager.AppSettings["GarunteeTypeCode"].ToString(),// "CC",
                                    PaymentMethod = new Models.OWS.PaymentMethod()
                                    {
                                        ExpiryDate = !string.IsNullOrEmpty(paymentDetails.paymentHeaders[x].ExpiryDate) ? "01/" + paymentDetails.paymentHeaders[x].ExpiryDate : null,
                                        MaskedCardNumber = paymentDetails.paymentHeaders[x].MaskedCardNumber,
                                        PaymentType = paymentDetails.paymentHeaders[x].OperaPaymentTypeCode

                                    }
                                }
                            }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                            if (!owsResponse.result)
                            {
                                new LogHelper().Log("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", ActionName, ActionGroup); new LogHelper().Warn("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", ActionName, ActionGroup);
                            }
                            else
                            {
                                new LogHelper().Log("Updating credit card details in the reservation succeeded", "", ActionName, ActionGroup);
                                new LogHelper().Warn("Updating credit card details in the reservation succeeded", "", ActionName, ActionGroup);
                            }
                            #endregion

                            #region Updating UDF fields in Opera reservation
                            try
                            {
                                new LogHelper().Log("Updating pre auth code and amount in UDF fileds", "", ActionName, ActionGroup); owsResponse = await new CloudHelper().ModifyBooking(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                                    modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                    {
                                        isUDFFieldSpecified = true,
                                        ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                        uDFFields = new List<Models.OWS.UDFField>()
                                                                                {
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.pspReferenceNumber
                                                                                    },
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthAmntUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.Amount
                                                                                    }
                                                                                }
                                    }
                                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString()
);
                                if (!owsResponse.result)
                                {
                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                    new LogHelper().Warn("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", ActionName, ActionGroup);
                                }
                                else
                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds succeeded ", "", ActionName, ActionGroup);
                            }
                            catch (Exception ex)
                            {
                                new LogHelper().Error(ex, "", ActionName, ActionGroup);
                            }
                            #endregion

                        }
                        else if (paymentDetails.paymentHeaders[x].TransactionType.Equals(Models.TransactionType.Sale.ToString()))
                        {
                            paymentDetails.paymentHeaders[x].IsActive = false;

                            #region Updating Card details in opera Reservation
                            new LogHelper().Log("Updating credit card details in the reservation", "", ActionName, ActionGroup);

                            Models.OWS.OwsResponseModel owsResponse = await new CloudHelper().UpdateCardDetailsInReservationAsyn(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                            {
                                ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                                LegNumber = "1",
                                Language = ConfigurationManager.AppSettings["Language"].ToString(),
                                Password = ConfigurationManager.AppSettings["Password"].ToString(),
                                Username = ConfigurationManager.AppSettings["Username"].ToString(),
                                SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                                modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                {
                                    ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                    isUDFFieldSpecified = false,
                                    updateCreditCardDetails = true,
                                    GarunteeTypeCode = ConfigurationManager.AppSettings["GarunteeTypeCode"].ToString(),//"CC",
                                    PaymentMethod = new Models.OWS.PaymentMethod()
                                    {
                                        ExpiryDate = !string.IsNullOrEmpty(paymentDetails.paymentHeaders[x].ExpiryDate) ? "01/" + paymentDetails.paymentHeaders[x].ExpiryDate : null,
                                        MaskedCardNumber = paymentDetails.paymentHeaders[x].MaskedCardNumber,
                                        PaymentType = paymentDetails.paymentHeaders[x].OperaPaymentTypeCode

                                    }
                                }
                            }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                            if (!owsResponse.result)
                            {
                                new LogHelper().Log("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", ActionName, ActionGroup); new LogHelper().Warn("Updating credit card details in the reservation failled with reason :- " + owsResponse.responseMessage, "", ActionName, ActionGroup);
                            }
                            else
                            {
                                new LogHelper().Log("Updating credit card details in the reservation succeeded", "", ActionName, ActionGroup);
                                new LogHelper().Warn("Updating credit card details in the reservation succeeded", "", ActionName, ActionGroup);
                            }
                            #endregion

                            #region Updating UDF fields in Opera reservation
                            try
                            {
                                new LogHelper().Log("Updating pre auth code and amount in UDF fileds", "", ActionName, ActionGroup); owsResponse = await new CloudHelper().ModifyBooking(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                                    modifyBookingRequest = new Models.OWS.ModifyBookingRequest()
                                    {
                                        isUDFFieldSpecified = true,
                                        ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                                        uDFFields = new List<Models.OWS.UDFField>()
                                                                                {
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.pspReferenceNumber
                                                                                    },
                                                                                    new Models.OWS.UDFField()
                                                                                    {
                                                                                        FieldName  = ConfigurationManager.AppSettings["PreAuthAmntUDF"].ToString(),
                                                                                        FieldValue = paymentHeader.Amount
                                                                                    }
                                                                                }
                                    }
                                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                                if (!owsResponse.result)
                                {
                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", ActionName, ActionGroup); new LogHelper().Warn("Updating pre auth code and amount in UDF fileds failled with reason : - " + owsResponse.responseMessage, "", ActionName, ActionGroup);
                                }
                                else
                                    new LogHelper().Log("Updating pre auth code and amount in UDF fileds succeeded ", "", ActionName, ActionGroup);
                            }
                            catch (Exception ex)
                            {
                                new LogHelper().Error(ex, "", ActionName, ActionGroup);
                            }
                            #endregion

                            #region Posting payment in opera reservation
                            try
                            {
                                new LogHelper().Log("Posting payment in the reservation", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                owsResponse = await new CloudHelper().MakePayment(SessionData.OperaReservation.ReservationNameID, new Models.OWS.OwsRequestModel()
                                {
                                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                                    LegNumber = "1",
                                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                                    MakePaymentRequest = new Models.OWS.MakePaymentRequest()
                                    {
                                        Amount = Convert.ToDecimal(paymentHeader.Amount),
                                        PaymentInfo = "Payment from web checkin",
                                        StationID = "MCI",
                                        WindowNumber = 1,
                                        ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                                        MaskedCardNumber = paymentHeader.MaskedCardNumber.ToLower(),
                                        PaymentRefernce = "Payment from web checkin - Sale",
                                        PaymentTypeCode = paymentHeader.OperaPaymentTypeCode,
                                        ApprovalCode = paymentHeader.pspReferenceNumber
                                    }
                                }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                                if (!owsResponse.result)
                                {
                                    new LogHelper().Log("Posting payment failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                    new LogHelper().Warn("Posting payment failled with reason : - " + owsResponse.responseMessage, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                                }
                                else
                                    new LogHelper().Log("Posting payment in opera reservation succeeded ", "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }
                            catch (Exception ex)
                            {
                                new LogHelper().Error(ex, "", "FetchPreCheckedInReservation", "pre checked-in fetch");
                            }
                            #endregion
                        }
                        else if (paymentDetails.paymentHeaders[x].TransactionType.Equals(Models.TransactionType.Capture.ToString()))
                        {
                            new LogHelper().Log("Wrong payment header retuned and Is active NULL (Capture)", "", ActionName, ActionGroup);
                            paymentDetails.paymentHeaders[x].IsActive = false;
                        }

                        #endregion
                    }
                    x++;
                }
                new LogHelper().Log("payment details updated successfully", "", ActionName, ActionGroup);
            }
            ////jkj
            #endregion

            #region Pushing Payment details in LOcal Db

            new LogHelper().Log("Updating payment details in local DB", "", ActionName, ActionGroup);
            var localResponse = await new CloudHelper().PushPaymentDetails(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
            {
                RequestObject = paymentDetails
            }, "pre checked-in fetch", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
            if (!localResponse.result)
            {
                new LogHelper().Log("Failled to update payment details in Local DB with reason :- " + localResponse.responseMessage, "", ActionName, ActionGroup); new LogHelper().Warn("Failled to update payment details in local DB with reason :- " + localResponse.responseMessage, "", ActionName, ActionGroup);
            }
            else
                new LogHelper().Log("Payment details updated successfully", "", ActionName, ActionGroup);
            #endregion
            #endregion
            if (localResponse.result)
            {
                #region Updating record status in Local DB
                new LogHelper().Log("Updating the reservation status in Local DB", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                localResponse = await new CloudHelper().UpdateReservationStatus(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                {
                    RequestObject = new ReservationStatusRequestModel
                    {
                        ReservationID = SessionData.OperaReservation.ReservationNameID,
                        Type = "EcomInComplete"
                    }
                }, "Due-In push", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());
                if (!localResponse.result)
                {
                    new LogHelper().Log("Updating the reservation status in Local DB with email send flag failled with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                }
                else
                    new LogHelper().Log("Updating the reservation status in Local DB ", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                #endregion
                #region  Precheckin Completed
                var reservationsDt = reservationLogics.GetReservationDetailsDT(ConfirmationNo);
                var reservations = Helpers.DataTableHelper.DataTableToList<DataAccess.usp_GetReservationDetails_Result>(reservationsDt);

                localResponse = await new CloudHelper().PushReservationTrackLocally(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                {
                    RequestObject = new Models.ReservationTrackStatus()
                    {
                        ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                        ProcessType = Models.ReservationProcessType.PreCheckedInFetched.ToString(),
                        ReservationNumber = SessionData.OperaReservation.ReservationNumber,
                        ProcessStatus = "",
                        EmailSent = false
                    }
                }, "pre checked-in fetch", ConfigurationManager.AppSettings
                 ["APIBaseUrl"].ToString());
                if (localResponse.result)
                {
                    new LogHelper().Log("Reservation track in local DB updated successfully ", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                }
                else
                {
                    new LogHelper().Log("Failled to update reservation track in local DB with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                }


                #endregion

              
                return Json(new { result = true });
            }
            else
            {
                return Json(new { result = false });
            }
        }

        [HttpPost]
        public async Task<ActionResult> SaveAdyenPaymentDetails(MakePaymentDetailModel makePaymentDetailModel, string ConfirmationNo, long TransactionID, string ReservationNameID, string TransactionType)
        {

            string ActionName = "SaveAdyenPaymentDetails", ActionGroup = "Pre-Checkin";

            Helpers.LogHelper.Instance.Log($"Updating payment PData", $"", ActionName, ActionGroup);
            try
            {
                List<Models.PaymentHistory> paymentHistory = new List<Models.PaymentHistory>();

                #region create paymenthistory
                paymentHistory.Add(new PaymentHistory
                {

                    MDData = "",
                    PaRes = "",
                    PData = makePaymentDetailModel.paymentData,
                    PSPReference = "",
                    RefusalReason = "",
                    ReservationNameID = ReservationNameID,
                    ReservationNumber = ConfirmationNo,
                    ResultCode = "",
                    TransactionID = TransactionID.ToString(),
                    TransactionType = TransactionType

                });
                #endregion
                #region Pushing Payment details in LOcal Db

                new LogHelper().Log("Updating payment details in local DB", "", ActionName, ActionGroup);
               
                var localResponse = await new CloudHelper().PushPaymentHistoryDetails(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
                {
                    RequestObject = paymentHistory
                }, "pre checked-in fetch", ConfigurationManager.AppSettings
          ["APIBaseUrl"].ToString());
                if (!localResponse.result)
                {
                    new LogHelper().Log("Failled to update payment details in Local DB with reason :- " + localResponse.responseMessage, "", ActionName, ActionGroup);
                    new LogHelper().Warn("Failled to update payment details in local DB with reason :- " + localResponse.responseMessage, "", ActionName, ActionGroup);
                }
                else
                    new LogHelper().Log("Payment details updated successfully", "", ActionName, ActionGroup);
                #endregion
                return Json(new { result = true });
            }
            catch (Exception ex)
            {
                Helpers.LogHelper.Instance.Log($"Failled insert the payment details  {ex.ToString()}", $"", ActionName, ActionGroup);
                return Json(new { result = false });
            }

        }

        public ActionResult CalculatePreAuthAmount(string ReservationNumber, string FundingSource, string PaymentMethod)
        {
            string ActionName = "CalculatePreAuthAmount", ActionGroup = "Pre-Checkin";
            int incidentalCap = -1;
            decimal IncidentialCharge = 100;
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["IncidentalCapValue"].ToString()))
            {
                incidentalCap = Int32.Parse(ConfigurationManager.AppSettings["IncidentalCapValue"].ToString());
            }
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["IncidentalCharge"].ToString()))
            {
                IncidentialCharge = Int32.Parse(ConfigurationManager.AppSettings["IncidentalCharge"].ToString());
            }
            //Get the reservation details for room rate
            var reservationsDt = reservationLogics.GetReservationDetailsDT(ReservationNumber);
            var reservations = Helpers.DataTableHelper.DataTableToList<GetReservationDetailsModel>(reservationsDt);

            Helpers.LogHelper.Instance.Log($"Calculating Pre-Auth Amount", $"", ActionName, ActionGroup);

            if (reservations != null && reservations.Count > 0)
            {
                var reservation = reservations.FirstOrDefault();
                var ReservationPackages = reservationLogics.GetReservationPackages(reservation.ReservationDetailID);
                if (ReservationPackages != null && ReservationPackages.Count > 0)
                {
                    ReservationPackages = ReservationPackages.Where(x => !x.IsRoomUpsell).ToList();
                }

                decimal packageAmount = 0;
                if (ReservationPackages != null)
                {
                    foreach (var item in ReservationPackages)
                    {
                        if (item.PackageAmount != null)
                        {
                            packageAmount += Convert.ToDecimal(item.PackageAmount.ToString());
                        }
                    }
                }

                decimal PreuthAmount = 0;
                decimal roomrate = reservation.TotalAmount != null ? reservation.TotalAmount.Value : 0;
                int paxCount = reservation.Adultcount != null ? reservation.Adultcount.Value : 1;
                //decimal IncidentialCharge = 100;
                int NoofNights = (reservation.DepartureDate.Value - reservation.ArrivalDate.Value).Days;

                if (NoofNights == 0)
                {
                    NoofNights = 1;
                }

                List<string> AuthoRuleOneReservationTypes = new List<string>();
                AuthoRuleOneReservationTypes.Add("GCC");
                AuthoRuleOneReservationTypes.Add("GCO");
                AuthoRuleOneReservationTypes.Add("NON");

                List<string> AuthoRuleTwoReservationTypes = new List<string>();
                AuthoRuleTwoReservationTypes.Add("GRD");
                AuthoRuleTwoReservationTypes.Add("DEP");
                //AuthoRuleTwoReservationTypes.Add("TA");
                //AuthoRuleTwoReservationTypes.Add("GT");

                string ReservationType = reservation.ReservationSource != null ? reservation.ReservationSource : "";


                if (AuthoRuleOneReservationTypes.Any(x => x.Contains(ReservationType)))
                {
                    //Rule 1

                    if (FundingSource == "CREDIT")
                    {
                        if (!string.IsNullOrEmpty(PaymentMethod) && (PaymentMethod.ToUpper().Contains("JCB") || PaymentMethod.ToUpper().Contains("CUP")))
                        {
                            //PreuthAmount = roomrate;// No incidental charge for JCB and CUP
                            //IncidentialCharge = 1;
                            // PreuthAmount = 0; //Changed as per the  support ticket number 418
                            PreuthAmount = roomrate;// Updated as per  #2303

                        }
                        else
                        {
                            //PreuthAmount = roomrate + (NoofNights * IncidentialCharge);
                            // PreuthAmount = 1; //Changed as per the  support ticket number 418
                            PreuthAmount = roomrate + (NoofNights * IncidentialCharge);// Updated as per  #2303
                        }
                    }
                    else
                    {
                        //PreuthAmount = roomrate; // No incidental charge for DEBIT card
                        //IncidentialCharge = 0;
                        // PreuthAmount = 0; //Changed as per the  support ticket number 418
                        PreuthAmount = roomrate;// Updated as per  #2303
                    }

                }
                else if (AuthoRuleTwoReservationTypes.Any(x => x.Contains(reservation.ReservationSource)))
                {
                    //Rule 2

                    if (FundingSource == "CREDIT")
                    {
                        if (!string.IsNullOrEmpty(PaymentMethod) && (PaymentMethod.ToUpper() == "JCB" || PaymentMethod.ToUpper() == "CUP"))
                        {
                            //PreuthAmount = 0;// No incidental charge for JCB and CUP
                            //IncidentialCharge = 0;
                            // PreuthAmount = 0; //Changed as per the  support ticket number 418
                            // PreuthAmount = roomrate;// Updated as per  #2303
                            PreuthAmount = 0;

                        }
                        else
                        {
                            PreuthAmount = (NoofNights * IncidentialCharge);// Updated as per  #2303
                            //PreuthAmount = NoofNights * (IncidentialCharge);
                            //Changed as per the  support ticket number 418
                        }
                    }
                    else
                    {
                        //PreuthAmount = 0;// No incidental charge for DEBIT card
                        //IncidentialCharge = 0;
                        PreuthAmount = 0; //Changed as per the  support ticket number 418
                    }

                    roomrate = 0;

                }
                else
                {
                    //Default Rule
                    //PreuthAmount = NoofNights * (roomrate + IncidentialCharge);
                    //PreuthAmount = roomrate + (NoofNights * IncidentialCharge);//as room rate include all night charge formula changed
                    PreuthAmount = 0; //Changed as per the  support ticket number 418
                }



                if (PreuthAmount > incidentalCap)
                {
                    PreuthAmount = incidentalCap;
                }

                //if any packages selected in previously 
                PreuthAmount += packageAmount;

                Helpers.LogHelper.Instance.Log($"Calculated pre-auth Amount  {PreuthAmount}", $"", ActionName, ActionGroup);

                return Json(new { result = true, PreuthAmount = PreuthAmount, IncidentialCharge = IncidentialCharge, RoomRate = (roomrate + packageAmount), NoofNights = NoofNights });
            }
            return Json(new { result = false, AmountToCharge = 0 });
        }

        public ActionResult ValidateDocumentIssueCountry(string idType, string issueCountry)
        {
            string ActionName = "ValidateDocumentIssueCountry", ActionGroup = "Pre-Checkin";
            Helpers.LogHelper.Instance.Log($"Validating Document Type {idType} and Issue Country {issueCountry} ", $"", ActionName, ActionGroup);
            MastersLogics mastersLogics = new MastersLogics();
            var ResponseDataTable = mastersLogics.validateDocumentIssueCountry(idType, issueCountry);
            if (ResponseDataTable != null && ResponseDataTable.Rows.Count > 0)
            {
                if (ResponseDataTable.Rows[0][0].ToString() == "1")
                {
                    Helpers.LogHelper.Instance.Log($"Validating Document Type {idType} and Issue Country {issueCountry} is valid", $"", ActionName, ActionGroup);
                    return Json(new { result = true });
                }
                else
                {
                    Helpers.LogHelper.Instance.Log($"Validating Document Type {idType} and Issue Country {issueCountry} is not valid", $"", ActionName, ActionGroup);
                    return Json(new { result = false });
                }
            }
            else
            {
                Helpers.LogHelper.Instance.Log($"Validating Document Type {idType} and Issue Country {issueCountry} is not valid", $"", ActionName, ActionGroup);
                return Json(new { result = false });
            }
        }

        public async Task<ActionResult> PaybyLink(string id, string UniqueRefNo)
        {
            ViewBag.id = id;

            string ActionName = "PaybyLink";
            string ActionGroup = "Pre-Checkin";
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            var languageSession = "en";

            if (Request.Cookies.AllKeys.Contains("culture"))
            {
                languageSession = Request.Cookies["culture"].Value.ToString();
            }

            Session["SelectedLanguage"] = languageSession;

            var test = Url.Encode(Helpers.EncryptionHelper.EncryptString(id));
            if (string.IsNullOrEmpty(id))
            {
                return View("ReservationNotFound");
            }

            string confirmationNo = Helpers.EncryptionHelper.DecryptString(id.ToString());

            if (string.IsNullOrEmpty(confirmationNo))
            {
                Helpers.LogHelper.Instance.Warn($"Unable to decrypt the confirmation no {id.ToString()}", "0", ActionName, ActionGroup);
                return View("ReservationNotFound");
            }

            ViewBag.ReservationFound = false;
            ViewBag.PaymentProcessed = false;

            Models.ReservationModel reservationModel = new Models.ReservationModel();
            reservationModel.IsDepositAvailable = false;

            MastersLogics mastersLogics = new MastersLogics();

            var CountryList = await new CloudHelper().fetchcountryMaster(ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString(), ActionGroup);

            var reservationsDt = await new CloudHelper().FetchReservationDetailsByReferenceNumber(confirmationNo, new APIRequestModel { RequestObject = confirmationNo }, "", ConfigurationManager.AppSettings
                    ["APIBaseUrl"].ToString());
            var reservations = new CloudReservationModel();
            if (reservationsDt != null)
            {
                reservations = JsonConvert.DeserializeObject<List<CloudReservationModel>>(reservationsDt.responseData.ToString()).FirstOrDefault();

            }

            if (reservations != null)
            {
                var reservationfromopera = await new CloudHelper().fetchReservationFromPMS(new Models.OWS.OwsRequestModel()
                {
                    ChainCode = ConfigurationManager.AppSettings["ChainCode"].ToString(),
                    DestinationEntityID = ConfigurationManager.AppSettings["DestinationEntityID"].ToString(),
                    DestinationSystemType = ConfigurationManager.AppSettings["DestinationSystemType"].ToString(),
                    HotelDomain = ConfigurationManager.AppSettings["HotelDomain"].ToString(),
                    KioskID = ConfigurationManager.AppSettings["KioskID"].ToString(),
                    LegNumber = "1",
                    Language = ConfigurationManager.AppSettings["Language"].ToString(),
                    Password = ConfigurationManager.AppSettings["Password"].ToString(),
                    Username = ConfigurationManager.AppSettings["Username"].ToString(),
                    SystemType = ConfigurationManager.AppSettings["SystemType"].ToString(),
                    FetchBookingRequest = new Models.OWS.FetchBookingRequestModel()
                    {
                        ReservationNumber = confirmationNo

                    }
                }, ConfigurationManager.AppSettings["APIBaseUrl"].ToString(), "precheckin", ActionGroup);

                if (reservationfromopera != null && reservationfromopera.Count > 0)
                {

                    if (reservationfromopera.First().Adults != null && reservationfromopera.First().Adults.Value > 0)
                        SessionData.OperaReservation = reservationfromopera.First();

                    bool isredirectfromPaymentPage = false;
                    bool IsPaymentSuccess = false;
                    string PaymentFailureMessage = "";

                    if (TempData["IsredirectedfromPaymentPage"] != null)
                    {
                        isredirectfromPaymentPage = Convert.ToBoolean(TempData["IsredirectedfromPaymentPage"].ToString());
                        IsPaymentSuccess = Convert.ToBoolean(TempData["IsPaymentSuccess"].ToString());
                        PaymentFailureMessage = TempData["PaymentFailureMessage"].ToString();
                    }

                    ViewBag.IsredirectedfromPaymentPage = isredirectfromPaymentPage;
                    ViewBag.IsPaymentSuccess = IsPaymentSuccess;
                    ViewBag.PaymentFailureMessage = PaymentFailureMessage;




                    if (reservations.IsPreCheckedInPMS.HasValue && !reservations.IsPreCheckedInPMS.Value || isredirectfromPaymentPage)
                    {
                        ViewBag.ReservationFound = true;

                        #region Get the existing selected package and Upsells

                        var ReservationPackagesList = reservationLogics.GetReservationPackages(reservations.ReservationDetailID);

                        if (ReservationPackagesList != null && ReservationPackagesList.Count > 0)
                        {
                            Helpers.LogHelper.Instance.Log($"Existing reservation packages found.", $"{confirmationNo}", ActionName, ActionGroup);

                            var RoomUpsellPackages = ReservationPackagesList.Where(x => x.IsRoomUpsell).Select(x => x.PackageID).ToArray();
                            var SpecialsPackages = ReservationPackagesList.Where(x => !x.IsRoomUpsell).Select(x => x.PackageID).ToArray();

                            ViewBag.RoomUpsellPackages = string.Join(",", RoomUpsellPackages);
                            ViewBag.SpecialPackages = string.Join(",", SpecialsPackages);
                            ViewBag.ReservationPackagesList = ReservationPackagesList;
                        }
                        else
                        {
                            Helpers.LogHelper.Instance.Log($"Existing reservation packages not found.", $"{confirmationNo}", ActionName, ActionGroup);
                            ViewBag.RoomUpsellPackages = string.Empty;
                            ViewBag.SpecialPackages = string.Empty;
                            ViewBag.ReservationPackagesList = new List<ReservationPackageModel>();
                        }
                        #endregion
                        #region VerifyVIPReservationOrNot
                        new LogHelper().Log("Verifying reservation VIP status in UDF field", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        if (SessionData.OperaReservation.userDefinedFields != null && SessionData.OperaReservation.userDefinedFields.Count > 0)
                        {
                            if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthUDF"].ToString())) != null &&
                                SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthUDF"].ToString())).FieldValue.Equals("NO"))
                            {
                                new LogHelper().Log("Reservation is flagged not to take payment", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                {
                    new Models.OWS.DepositDetail()
                    {
                        Amount = 0,
                        CardExpiryDate = null,
                        CreditCardNumber = null,
                        IsCreditCardDeposit = false,
                        PaymentType = null
                    }
                };
                                SessionData.OperaReservation.IsDepositAvailable = true;
                            }
                            else if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthAmntUDF"])) != null &&
                                SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings
                    ["PreAuthAmntUDF"])).FieldValue.Equals("NO"))
                            {

                                new LogHelper().Log("Reservation is flagged not to take payment", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                        {
                            new Models.OWS.DepositDetail()
                            {
                                Amount = 0,
                                CardExpiryDate = null,
                                CreditCardNumber = null,
                                IsCreditCardDeposit = false,
                                PaymentType = null
                            }
                        };

                                SessionData.OperaReservation.IsDepositAvailable = true;
                            }
                        }
                        new LogHelper().Log("Verifying reservation VIP status in UDF field completed", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        #endregion

                        #region PaymentDesabling
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings
                    ["IsPaymentDisabled"]))
                        {
                            new LogHelper().Log("Disabling the payment as per the config", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            SessionData.OperaReservation.DepositDetail = new List<Models.OWS.DepositDetail>()
                {
                    new Models.OWS.DepositDetail()
                    {
                        Amount = 0,
                        CardExpiryDate = null,
                        CreditCardNumber = null,
                        IsCreditCardDeposit = false,
                        PaymentType = null
                    }
                };
                            SessionData.OperaReservation.IsDepositAvailable = true;
                        }
                        #endregion

                        #region Update ETA
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsETADefault"]))
                        {
                            new LogHelper().Log("Assigning NULL value to ETA as per the config", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            SessionData.OperaReservation.ExpectedArrivalTime = null;
                        }
                        #endregion

                        #region Processing RoomRate
                        new LogHelper().Log("Updating rate details", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        if (SessionData.OperaReservation.RateDetails != null && SessionData.OperaReservation.RateDetails.DailyRates != null && SessionData.OperaReservation.RateDetails.DailyRates.Count > 0)
                        {
                            decimal total_roomrate = SessionData.OperaReservation.RateDetails.DailyRates.Sum(x => x.Amount);
                            if (SessionData.OperaReservation.PrintRate != null && SessionData.OperaReservation.PrintRate.Value)
                                SessionData.OperaReservation.RateDetails.RateAmount = total_roomrate;
                            else
                                SessionData.OperaReservation.TotalAmount = 0;
                            new LogHelper().Log("Updating rate details completed", SessionData.OperaReservation.ReservationNameID, "Index", "Pre-Checkin");
                        }
                        else
                            new LogHelper().Log("Updating rate details failed because Rate details are blank in the reservation", SessionData.OperaReservation.ReservationNameID, "Index", "Pre-Checkin");
                        #endregion


                        #region Processing MealPlan
                        if (ConfigurationManager.AppSettings["IsBreakFastValidationWithUDF"] != null && Convert.ToBoolean(ConfigurationManager.AppSettings["IsBreakFastValidationWithUDF"]))
                        {
                            new LogHelper().Debug("Processing meal plan from UDF fields", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            if (SessionData.OperaReservation.userDefinedFields != null && SessionData.OperaReservation.userDefinedFields.Count > 0)
                            {
                                if (SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])) != null)
                                {

                                    if (!SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])).FieldValue.Equals("NP"))
                                    {
                                        string tempUDFValue = SessionData.OperaReservation.userDefinedFields.Find(x => x.FieldName.Equals(ConfigurationManager.AppSettings["MealPlanFieldName"])).FieldValue;
                                        if (!string.IsNullOrEmpty(tempUDFValue))
                                        {
                                            bool isPackageFound = false;
                                            if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(tempUDFValue))
                                                isPackageFound = true;
                                            if (isPackageFound)
                                            {
                                                SessionData.OperaReservation.IsBreakFastAvailable = true;
                                                new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                            }
                                        }
                                    }
                                    else
                                        new LogHelper().Log("Processing meal plan not updated (NP not present in UDF)", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup); ;
                                }
                            }
                            else
                                new LogHelper().Log("No UDF fields for meal plan not found", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        }
                        if (ConfigurationManager.AppSettings["IsBreakFastValidationWithPackage"] != null && Convert.ToBoolean(ConfigurationManager.AppSettings["IsBreakFastValidationWithPackage"]))
                        {
                            new LogHelper().Debug("Processing package list in the reservation for meal plan", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                            if (((SessionData.OperaReservation.PackageDetails != null && SessionData.OperaReservation.PackageDetails.Count > 0) || (SessionData.OperaReservation.PreferanceDetails != null && SessionData.OperaReservation.PreferanceDetails.Count > 0)) && (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["PackageCodes"]) && ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList() != null))
                            {
                                if (SessionData.OperaReservation.PackageDetails != null && SessionData.OperaReservation.PackageDetails.Count > 0)
                                {
                                    bool isPackageFound = false;
                                    foreach (Models.OWS.PackageDetails package in SessionData.OperaReservation.PackageDetails)
                                    {
                                        if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(package.PackageCode))
                                        {
                                            isPackageFound = true;
                                            break;
                                        }
                                    }
                                    if (isPackageFound)
                                    {
                                        SessionData.OperaReservation.IsBreakFastAvailable = true;
                                        new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                    }
                                }
                                if (SessionData.OperaReservation.PreferanceDetails != null && SessionData.OperaReservation.PreferanceDetails.Count > 0)
                                {
                                    if (SessionData.OperaReservation.IsBreakFastAvailable == null || !SessionData.OperaReservation.IsBreakFastAvailable.Value)
                                    {
                                        bool isPrefernceFound = false;
                                        foreach (Models.OWS.PreferanceDetails prefernce in SessionData.OperaReservation.PreferanceDetails)
                                        {
                                            if (ConfigurationManager.AppSettings["PackageCodes"].Split(';').ToList().Contains(prefernce.PreferanceCode))
                                            {
                                                isPrefernceFound = true;
                                                break;
                                            }
                                        }
                                        if (isPrefernceFound)
                                        {
                                            SessionData.OperaReservation.IsBreakFastAvailable = true;
                                            new LogHelper().Debug("Meal plan updated", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                                        }
                                    }
                                }
                            }
                            else
                                new LogHelper().Log("No package or prefernce list in the reservation for meal plan not found", SessionData.OperaReservation.ReservationNameID, ActionName, ActionGroup);
                        }
                        #endregion
                        if ((reservations.IsEcomchekinPaymentStaus != null && reservations.IsEcomchekinPaymentStaus.Value) || isredirectfromPaymentPage)
                        {
                            Helpers.LogHelper.Instance.Log($"Reservation #{confirmationNo} payment already done.", $"{confirmationNo}", ActionName, ActionGroup);
                            ViewBag.PaymentProcessed = true;
                            ViewBag.IsPaymentSuccess = true;
                        }

                        // var Questions = reservationLogics.GetQuestions();
                        var PackageLists = reservationLogics.GetPackages(SessionData.OperaReservation.RoomDetails.RoomType);
                        ViewBag.PackageList = PackageLists;
                        // ViewBag.Questions = Questions;

                        //push events to DB
                        reservationLogics.InsertEvent(reservations.ReservationDetailID, "Email Link Click");

                        Helpers.LogHelper.Instance.Log($"Getting prfile details", $"{confirmationNo}", ActionName, ActionGroup);
                        var ProfileList = await reservationLogics.GetReservationProfileList(reservations.ReservationDetailID);

                        ViewBag.Profiles = ProfileList;
                        ViewBag.CountryList = new SelectList(CountryList, "CountryMasterID", "Country_Full_name", ProfileList[0].CountryMasterID);

                        if (ProfileList[0].CountryMasterID != null)
                        {
                            var StateList = mastersLogics.GetStateListByCountryID(ProfileList[0].CountryMasterID.Value);
                            ViewBag.StateList = new SelectList(StateList, "StateMasterID", "Statename", ProfileList[0].StateMasterID);
                        }
                        else
                        {
                            List<Models.StateMaster> tbstateMasters = new List<Models.StateMaster>();
                            tbstateMasters.Add(new Models.StateMaster()
                            {
                                Statename = "Please select country",
                                StateMasterID = -1

                            });
                            ViewBag.StateList = new SelectList(tbstateMasters, "StateMasterID", "Statename", "Select State");

                        }
                        CountryList.Add(new tbCountryMaster()
                        {
                            CountryMasterID = -1,
                            Country_Full_name = "Please select nationality"
                        });
                        ViewBag.NationalityList = new SelectList(CountryList, "CountryMasterID", "Country_Full_name", "Please select nationality");




                        List<Models.Profile> profiles = new List<Models.Profile>();

                        foreach (var profile in ProfileList)
                        {
                            profiles.Add(new Models.Profile()
                            {
                                AddressLine1 = profile.AddressLine1,
                                AddressLine2 = profile.AddressLine2,
                                City = profile.City,
                                CountryID = profile.CountryMasterID,
                                Email = profile.Email,
                                FirstName = profile.FirstName,
                                LastName = profile.LastName,
                                Phone = profile.Phone,
                                PostalCode = profile.PostalCode != null ? profile.PostalCode : "",
                                StateID = profile.StateMasterID,
                                ProfileDetailID = profile.ProfileDetailID,
                                MiddleName = profile.MiddleName,
                                ProfileID = Convert.ToInt32(profile.ProfileID ?? "0")
                            });
                        }

                        decimal TotalRoomRate = 0;
                        TotalRoomRate = SessionData.OperaReservation.TotalAmount.HasValue ? SessionData.OperaReservation.TotalAmount.Value : 0;


                        string ExpectedTimeofArrival = "";

                        if (reservations.ETA.HasValue && !(reservations.ETA.Value.ToString("HH:mm") == "00:00"))
                        {
                            Helpers.LogHelper.Instance.Log($"Estimate time of arrival already exist {reservations.ETA.Value.ToString("HH:mm")} ", $"{confirmationNo}", ActionName, ActionGroup);
                            DateTime timeUtc = reservations.ETA.Value;
                            ExpectedTimeofArrival = Helpers.DateTimeHelper.ConvertFromUTC(timeUtc);
                        }

                        //Added For breakfast included
                        bool IsBreakFastAvailable;
                        if (SessionData.OperaReservation.IsBreakFastAvailable != null)
                        {
                            IsBreakFastAvailable = SessionData.OperaReservation.IsBreakFastAvailable.Value;
                        }
                        else if (reservations.IsBreakFastAvailable != null)
                        {
                            IsBreakFastAvailable = reservations.IsBreakFastAvailable.Value;
                        }
                        else
                        {
                            IsBreakFastAvailable = false;
                        }

                        reservationModel = new Models.ReservationModel()
                        {
                            ReservationNameID = SessionData.OperaReservation.ReservationNameID,
                            ReservationID = reservations.ReservationDetailID,
                            AdultCount = reservations.Adultcount.HasValue ? reservations.Adultcount.Value : 0,
                            ArrivalDate = reservations.ArrivalDate.HasValue ? reservations.ArrivalDate.Value.ToString("dd MMM yyyy") : "",
                            AverageRoomRate = SessionData.OperaReservation.RateDetails.DailyRates[0].Amount,
                            ChildCount = reservations.Childcount.HasValue ? reservations.Childcount.Value : 0,
                            DepartureDate = reservations.DepartureDate.HasValue ? reservations.DepartureDate.Value.ToString("dd MMM yyyy") : "",
                            ExpectedTimeofArrival = ExpectedTimeofArrival,
                            FlightNo = reservations.FlightNo,
                            IsMembershipRequested = reservations.IsMemberShipEnrolled.HasValue ? reservations.IsMemberShipEnrolled.Value : false,
                            IsTermsAndConditions = false,
                            MembershipNo = reservations.MembershipNo,
                            ReservationNumber = reservations.ReservationNumber,
                            Profiles = profiles,
                            Questions = null,
                            RoomType = reservations.RoomType,
                            RoomTypeDescription = SessionData.OperaReservation.RoomDetails.RoomTypeDescription,
                            TotalRoomRate = TotalRoomRate,
                            IsDepositAvailable = reservations.IsDepositAvailable != null ? reservations.IsDepositAvailable.Value : false,
                            IsBreakFastAvailable = IsBreakFastAvailable,
                        };

                        QRCodeGenerator qrGenerator = new QRCodeGenerator();
                        QRCodeData qrCodeData = qrGenerator.CreateQrCode(confirmationNo, QRCodeGenerator.ECCLevel.Q);
                        QRCode qrCode = new QRCode(qrCodeData);
                        Bitmap qrCodeImage = qrCode.GetGraphic(20);

                        System.IO.MemoryStream ms = new MemoryStream();
                        qrCodeImage.Save(ms, ImageFormat.Jpeg);
                        byte[] byteImage = ms.ToArray();
                        var QRCodeBase64 = Convert.ToBase64String(byteImage);

                        ViewBag.QRcode = QRCodeBase64;

                        ViewBag.AdaptorAPIBaseURL = ConfigurationManager.AppSettings["AdaptorAPIBaseURL"].ToString();
                        ViewBag.CalQRcode = "";
                        Helpers.LogHelper.Instance.Log($"Reservation  {confirmationNo} successfully returned", $"{confirmationNo}", ActionName, ActionGroup);
                        return View(reservationModel);

                    }
                    else
                    {
                        Helpers.LogHelper.Instance.Warn($"Reservation {confirmationNo} already completed the pre-checkin, return reservation not found page", $"{confirmationNo}", ActionName, ActionGroup);
                        // Reservation not found page
                        return View("ReservationNotFound");
                    }
                }
                else
                {
                    Helpers.LogHelper.Instance.Warn($"Reservation not found for given confirmation no {confirmationNo}", $"{confirmationNo}", ActionName, ActionGroup);
                    // Reservation not found page
                    return View("ReservationNotFound");
                }
            }
            else
            {
                Helpers.LogHelper.Instance.Warn($"Reservation not found for given confirmation no {confirmationNo}", $"{confirmationNo}", ActionName, ActionGroup);
                return View("ReservationNotFound");
            }
        }

        public string GetStatelist(int Id)
        {
            var StateList = new MastersLogics().GetStateListByCountryID(Id);
            if (StateList != null && StateList.Count() > 0)
            {
                return StateList.FirstOrDefault().StateCode;
            }

            return "";
        }
        public string GetCountry(int Id)
        {
            var countryList = new MastersLogics().GetCountryList();
            if (countryList != null && countryList.Count() > 0)
            {
                var countrydetails = countryList.Where(x => x.CountryMasterID == Id).ToList();
                if (countrydetails != null && countrydetails.Count() > 0)
                {
                    return countrydetails.FirstOrDefault().Country_2Char_code;
                }
                return "";
            }
            
            return "";
        }
        public string GetCountryByCode(string Id)
        {
            var countryList = new MastersLogics().GetCountryList();
            if (countryList != null && countryList.Count() > 0)
            {
                var countrydetails = countryList.Where(x => x.Country_Full_name == Id || x.Country_3Char_code==Id).ToList();
                if (countrydetails != null && countrydetails.Count() > 0)
                {
                    return countrydetails.FirstOrDefault().Country_2Char_code;
                }
                return "";
            }

            return "";
        }

        public string GetDocumentByCode(string Id)
        {

            var DocumentList = new MastersLogics().GetDocumentList();
            if (DocumentList != null && DocumentList.Count() > 0)
            {
                var documentdetails = DocumentList.Where(x => x.DocumentCode == Id).ToList();
                if (documentdetails != null && documentdetails.Count() > 0)
                {
                    return documentdetails.FirstOrDefault().OperaDocumentCode;
                }
                return "";
            }

            return "";
        }

        public string GetStateById(int Id)
        {
            var StateList = new MastersLogics().GetStateList();
            if (StateList != null && StateList.Count() > 0)
            {
                var Statedetails = StateList.Where(x => x.StateMasterID == Id).ToList();
                if (Statedetails != null && Statedetails.Count() > 0)
                {
                    return Statedetails.FirstOrDefault().StateCode;
                }
                return "";
            }

            return "";
        }
        private string getPrimaryEmail()
        {
            if (SessionData.OperaReservation != null &&
                SessionData.OperaReservation.GuestProfiles != null &&
                SessionData.OperaReservation.GuestProfiles.Count > 0 &&
                SessionData.OperaReservation.GuestProfiles.First().Email != null &&
                SessionData.OperaReservation.GuestProfiles.First().Email.Count > 0)
            {
                var ProfileEmail = SessionData.OperaReservation.GuestProfiles.First().Email.Where(x => x.primary != null && x.primary.Value).ToList();
                if (ProfileEmail != null)
                {
                    return ProfileEmail.First().email;
                }
                else
                {
                    return SessionData.OperaReservation.GuestProfiles.First().Email.First().email;
                }
            }
            else
                return "";
        }
        private string getPrimaryPhone()
        {
            if (SessionData.OperaReservation != null &&
               SessionData.OperaReservation.GuestProfiles != null &&
               SessionData.OperaReservation.GuestProfiles.Count > 0 &&
                SessionData.OperaReservation.GuestProfiles.First().Phones != null &&
                SessionData.OperaReservation.GuestProfiles.First().Phones.Count > 0)
            {
                var ProfileEmail = SessionData.OperaReservation.GuestProfiles.First().Phones.Where(x => x.primary != null && x.primary.Value).ToList();
                if (ProfileEmail != null)
                {
                    return ProfileEmail.First().PhoneNumber;
                }
                else
                {
                    return SessionData.OperaReservation.GuestProfiles.First().Phones.First().PhoneNumber;
                }
            }
            else
                return "";
        }

        [HttpPost]
        public async Task<ActionResult> CompletedocUploadAsync(int ReservationID)
        {
            #region Updating record status in Local DB
            new LogHelper().Log("Updating the reservation status in Local DB", SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
            var localResponse = await new CloudHelper().UpdateReservationStatus(SessionData.OperaReservation.ReservationNameID, new Models.APIRequestModel()
            {
                RequestObject = new ReservationStatusRequestModel
                {
                    ReservationID = SessionData.OperaReservation.ReservationNameID,
                    Type = "PreCheckinComplete"
                }
            }, "Due-In push", ConfigurationManager.AppSettings["APIBaseUrl"].ToString());

            if (!localResponse.result)
            {
                new LogHelper().Log("Updating the reservation status in Local DB with email send flag failled with reason :- " + localResponse.responseMessage, SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
            }
            else
                new LogHelper().Log("Updating the reservation status in Local DB ", SessionData.OperaReservation.ReservationNameID, "PushDueInReservation", "Due-In push");
            #endregion

            return Json(new { result = true });
        }

        public ActionResult PaymentSkipped(int ReservationID)
        {

            Helpers.LogHelper.Instance.Log($"PaymentSkip", $"{ReservationID}", "PaymentSkipped", "Pre-Checkin");

            reservationLogics.UpdateReservationByStage("PaymentSkip", new UpdateReservationModel()
            {
                ReservationID = ReservationID
            });
            if (ViewBag.uploadcomplete)
            {
                reservationLogics.UpdateReservationByStage("Finish", new UpdateReservationModel()
                {
                    ReservationID = ReservationID
                });
            }

            return Json(new { result = true });
        }
        [HttpPost]
        public JsonResult ConvertPdfToImage(HttpPostedFileBase pdfFile, string ReservationID)
        {
            if (pdfFile != null && pdfFile.ContentLength > 0)
            {
                try
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        pdfFile.InputStream.CopyTo(memoryStream);
                        memoryStream.Position = 0;

                        using (var document = PdfiumViewer.PdfDocument.Load(memoryStream))
                        {
                            // Render the first page (page index 0)
                            using (var image = document.Render(0, 300, 300, true))
                            {
                                using (var imgStream = new MemoryStream())
                                {
                                    image.Save(imgStream, System.Drawing.Imaging.ImageFormat.Png);

                                    //string base64String = "data:image/png;base64," +
                                    //    Convert.ToBase64String(imgStream.ToArray());
                                    string base64String = Convert.ToBase64String(imgStream.ToArray());
                                    return Json(new
                                    {
                                        Success = true,
                                        Base64Image = base64String
                                    });
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    return Json(new { Success = false, Message = ex.Message });
                }
            }

            return Json(new { Success = false, Message = "No file uploaded!" });
        }
        [HttpPost]
        public ActionResult ScanResult()
        {
            try
            {
                Request.InputStream.Position = 0;
                using (var reader = new StreamReader(Request.InputStream))
                {
                    var body = reader.ReadToEnd();
                    // Get the path to the bin folder
                    string binPath = AppDomain.CurrentDomain.BaseDirectory;

                    // Combine with file name
                    string filePath = Path.Combine(binPath, "ScanResult.txt");

                    // Write JSON to file

                    System.IO.File.WriteAllText(filePath, body);

                    return Json(new { status = "received", data = body });
                }
            }
            catch (Exception ex)
            {
                return Json(new { error = true, message = ex.Message });
            }
        }

        [HttpGet]
        public JsonResult GetApiToken()
        {
            var token = AuthenticationHelper.GetAPIAccessToken();
            return Json(new { token = token }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public async Task<ActionResult> SearchReservation()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> SearchReservation(string ConfirmationNo)
        {
            ConfirmationNo = ConfirmationNo.Trim();
            var reservationsDt = reservationLogics.GetReservationDetailsDT(ConfirmationNo);
            var reservations = Helpers.DataTableHelper.DataTableToList<usp_GetReservationDetails_Result>(reservationsDt);
            if (reservations != null && reservations.Count > 0)
            {
                string ConfirmationNumber = Url.Encode(Helpers.EncryptionHelper.EncryptString(ConfirmationNo));
                string hostedUrl = Request.Url.GetLeftPart(UriPartial.Authority) + Request.ApplicationPath.TrimEnd('/');
                var uri = Path.Combine(hostedUrl, "Home", $"Index?id={ConfirmationNumber}");
                return Json(new { result = true, redirectUrl = uri });
            }
            else
            {
                var response = await reservationLogics.FetchReservationDetailFromPMS(ConfirmationNo);
                if (response != null && response.Count() > 0)
                {
                    reservationsDt = reservationLogics.GetReservationDetailsDT(response[0].ReservationNumber);
                    reservations = Helpers.DataTableHelper.DataTableToList<usp_GetReservationDetails_Result>(reservationsDt);
                    if (reservations != null && reservations.Count > 0)
                    {
                        string ConfirmationNumber = Url.Encode(Helpers.EncryptionHelper.EncryptString(reservations[0].ReservationNumber));
                        string hostedUrl = Request.Url.GetLeftPart(UriPartial.Authority) + Request.ApplicationPath.TrimEnd('/');
                        var uri = Path.Combine(hostedUrl, "Home", $"Index?id={ConfirmationNumber}");
                        return Json(new { result = true, redirectUrl = uri });
                    }
                    else
                    {
                        await reservationLogics.PushDueInSearchedReservation(response[0].ReservationNumber);
                        reservationsDt = reservationLogics.GetReservationDetailsDT(response[0].ReservationNumber);
                        reservations = Helpers.DataTableHelper.DataTableToList<usp_GetReservationDetails_Result>(reservationsDt);
                        if (reservations != null && reservations.Count > 0)
                        {
                            string ConfirmationNumber = Url.Encode(Helpers.EncryptionHelper.EncryptString(response[0].ReservationNumber));
                            string hostedUrl = Request.Url.GetLeftPart(UriPartial.Authority) + Request.ApplicationPath.TrimEnd('/');
                            var uri = Path.Combine(hostedUrl, "Home", $"Index?id={ConfirmationNumber}");
                            return Json(new { result = true, redirectUrl = uri });
                        }
                    }
                }

                return Json(new { result = false, redirectUrl = string.Empty, errorMessage = "Reservation Not Found!" });
            }
        }
    }

}